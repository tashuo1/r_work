# cizhu-shengcheng portable skill

?????????????/????????????-????????????? Codex ? Claude ??????

## ??

Codex:

```powershell
Copy-Item -Recurse cizhu-shengcheng-portable $env:USERPROFILE\.codex\skills\cizhu-shengcheng
```

Claude ??? Agent:

??? `cizhu-shengcheng-portable` ??????? skills/agents ????????????????? `SKILL.md`?

## ??????

```powershell
$env:CIZHU_SKILL_HOME="C:\path\to\cizhu-shengcheng-portable"
$env:CIZHU_DM_URL="jdbc:dm://127.0.0.1:5236"
$env:CIZHU_DM_USER="SYSDBA"
$env:CIZHU_DM_PASSWORD="your_dm_password"
$env:CIZHU_MYSQL_URL="jdbc:mysql://host:3306/ontology_meta?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&rewriteBatchedStatements=true"
$env:CIZHU_MYSQL_USER="root"
$env:CIZHU_MYSQL_PASSWORD="your_mysql_password"
$env:CIZHU_MYSQL_HOST="host"
$env:CIZHU_MYSQL_PORT="3306"
$env:CIZHU_MYSQL_DATABASE="ontology_meta"
```

Python ???? `CIZHU_MYSQL_HOST/PORT/DATABASE`?Java ?????? `CIZHU_MYSQL_URL`?

## ????

```powershell
python -m pip install pymysql pypinyin jieba

$cp="path\DmJdbcDriver18.jar;path\mysql-connector-j.jar;path\pinyin4j.jar"
javac -encoding UTF-8 -cp $cp scripts\UsableDictionaryWriter.java scripts\DmStandardFieldCoverageAudit.java scripts\SkillAssetDraftFieldRepair.java scripts\ControlledUnsplitDraftRepair.java scripts\UnsplitReviewArtifactExporter.java

java -cp "scripts;$cp" UsableDictionaryWriter
java -cp "scripts;$cp" DmStandardFieldCoverageAudit
java -cp "scripts;$cp" SkillAssetDraftFieldRepair
java -cp "scripts;$cp" ControlledUnsplitDraftRepair
python scripts\jieba_tokenizer_candidates.py --limit 5000
python scripts\jieba_root_whitelist_builder.py
python scripts\jieba_candidate_draft_writer.py --limit 1200 --allow-unknown
python scripts\backfill_governance_fields.py
java -cp "scripts;$cp" DmStandardFieldCoverageAudit
python scripts\jieba_coverage_audit.py
```

## ????

????????????????????????????

`ACTIVE` ???????????????????/??????????
