---
name: cizhu-shengcheng
description: Generate and audit ontology term roots, standard fields, physical-field mappings, and synonym candidates from business database metadata. Use when Codex needs to normalize database fields into Chinese-pinyin roots and underscore-composed standard fields, review ontology dictionary quality, prepare data for om_term_root/om_standard_field/om_root_field_map/om_root_synonym, or diagnose confusion between roots, standard fields, abbreviations, and synonyms.
---

# Cizhu Shengcheng

## Purpose

Use this skill to turn business database metadata into ontology dictionary candidates without polluting the formal dictionary tables. The enterprise target is practical coverage with strict boundaries:

```text
ACTIVE coverage for effective business fields >= 70%
DRAFT candidate coverage for reviewable remainder >= 20%
term-root pollution = 0
every generated field has an evidence chain and review reason
```

Core rule:

```text
term root = one Chinese business word in full lowercase pinyin
standard field = one or more registered normative roots joined by "_"
```

Do not let an LLM write directly to the four formal tables. Produce candidates, evidence, validation findings, and only then prepare reviewed inserts.

## Required Workflow

1. Load `references/root-field-standard.md` when the task involves rule details, table boundaries, or ambiguous cases. Load `references/enterprise-pipeline.md` for generation, audit, or improvement work.
2. Collect evidence for each physical field:
   `schema_name`, `table_name`, `table_comment`, `column_name`, `column_comment`, `data_type`, `nullable`, `primary_key/index hints`, masked `sample_values`, `distinct_count`, `null_ratio`, `top_enum_values`, and same-table field context.
3. Filter system tables and pure technical noise. Platform/config/template fields may be rejected from ACTIVE business modeling, but still produce DRAFT candidates when their Chinese semantics are clear and reviewable.
4. Generate candidates in this order:
   review memory -> base common roots -> business-domain roots -> semantic inference -> standard fields -> root-field mappings -> root synonyms.
5. Classify every candidate:
   `AUTO`, `CANDIDATE_HIGH`, `CANDIDATE_LOW`, `PENDING_REVIEW`, or `REJECTED`.
6. Run deterministic validation before any insert. Use `scripts/validate_dictionary.py` for CSV/JSON artifacts, or implement equivalent checks in the project language.
7. Write strong-rule `AUTO` results as `ACTIVE`. Write reviewable L2/L3/low-confidence results as `DRAFT`, with `om_root_field_map.status = INACTIVE`. Never drop a field with clear Chinese semantics merely because a root is missing.
   Exception: tokenizer/LLM-derived atomic roots whose Chinese `root_name` length is 1 or 2 are auto-promoted to `ACTIVE` after root-boundary validation, because short atomic Chinese business words are low-risk reusable roots. This exception applies only to `om_term_root`, not to composed standard fields.
8. Treat existing `ACTIVE` dictionary rows as immutable. Do not update, overwrite, downgrade, delete, or regenerate `ACTIVE` rows unless the user explicitly asks for an ACTIVE data migration.
9. Persist human review decisions into `references/review-memory.yml` or a project review-memory artifact, then load those decisions before the next run.

## Hard Rules

- `om_term_root` stores words, never fields.
- `om_standard_field` stores field semantics composed only from normative roots.
- `om_root_field_map` stores how roots compose or assist fields.
- `om_root_synonym` stores root-to-root relations only.
- A root code must not contain `_`, numbers, spaces, English words, source column names, or field-level compound semantics.
- A standard field must split completely into existing normative roots.
- Auxiliary recognition roots such as initials or legacy abbreviations must never compose standard fields.
- `SYNONYM` in `om_root_field_map` means "direct field component"; `SYNONYM` in `om_root_synonym` means "root equivalence". Do not mix these meanings.
- Never create a root by removing underscores from a standard field. `fuji_biaoshi` must not become `fujibiaoshi`.
- Platform/config/report/template metadata such as table title, table identifier, target table definition, mapping template, approval node, and form configuration must not enter the formal business dictionary unless the table is manually confirmed as a business object.
- Missing roots must be generated as atomic `DRAFT` roots when field semantics are clear enough to review. Do not discard the field and do not create a compound root.
- Before creating any `DRAFT` root from an unknown Chinese phrase, the generator must first try to split it with existing ACTIVE/DRAFT roots and skill root assets. If it can split into two or more atomic roots, create or reuse the underscore standard field instead of creating a compound root.
- Tokenizer/LLM unknown roots with Chinese `root_name` length <= 2 may be written as `ACTIVE` after validation. Roots with `root_name` length > 2 remain `DRAFT` unless review memory explicitly confirms them.
- Existing `ACTIVE` rows are protected data. Only create new rows or update non-`ACTIVE` rows during normal regeneration/review workflows.
- Standard-field coverage is measured by physical-field mappings, not dictionary row counts.
- Missing confirmed roots must reduce status to `DRAFT`, not eliminate the field candidate.

Forbidden root examples:

```text
yonghuleixing
xiugaishijian
caozuoshijian
danjubianhao
fujibiaoshi
moxingbiaoshi
kehumingcheng
biaobiaoshi
biaobiaoti
mubiaobiao
mubiaobiaodingyi
guanlianmoban
```

Correct standard field examples:

```text
yonghu_leixing
xiugai_shijian
caozuo_shijian
danju_bianhao
fuji_biaoshi
moxing_biaoshi
kehu_mingcheng
```

## Evidence Chain

Judge field semantics from four evidence types together:

```text
field name evidence + sample value evidence + table context evidence + same-table field evidence
```

Rules:

- Chinese column comments are high-value evidence, but still require filtering and splitting.
- Sample values verify shape only; they do not decide business口径 alone.
- A generic field such as `DATE`, `RQ`, `STATUS`, `TYPE`, `FLAG`, `NAME`, or `BH` needs object context.
- If evidence conflicts, mark `PENDING_REVIEW` or `REJECTED`; do not force a standard field.
- Sample values and enum distributions can confirm shape and state semantics, but must not override clear business comments.
- LLM inference must produce structured rationale; it must not directly write database rows.

## Knowledge Assets

Load only the relevant files:

- `references/common-roots.yml`: base roots that should exist before scanning any business database.
- `references/domain-roots-finance.yml`: finance/accounting/debt/guarantee roots.
- `references/domain-roots-hr.yml`: HR and organization roots.
- `references/domain-roots-investment.yml`: investment/project/contract roots.
- `references/platform-stopwords.yml`: platform, metadata, config, workflow, and log terms that should not enter ACTIVE business dictionaries by default.
- `references/abbreviation-dictionary.yml`: approved abbreviation and legacy-code expansion rules.
- `references/review-memory.yml`: human-confirmed promotions, rejections, aliases, and split overrides from previous runs.
- `references/aliyun-tokenizer.md`: Aliyun NLP tokenizer integration contract and safety rules.
- `references/jieba-tokenizer.md`: local open-source jieba tokenizer integration and safety rules.
- `references/report-metric-modeling.md`: special rules for finance/report-line metric fields.
- Existing formal tables also carry candidate governance. Use `status`, `source_type`, `confidence_level`, `evidence_json`, and `review_note` on `om_term_root` and `om_standard_field` instead of creating separate candidate tables.

When a project has its own equivalent files, prefer the project files and merge only non-conflicting skill defaults.

## Enterprise Pipeline

Use the pipeline in `references/enterprise-pipeline.md` for generation or audit. In short:

```text
scan -> evidence profile -> semantic_cn -> root split -> standard field -> validation -> write ACTIVE/DRAFT -> coverage audit -> review memory
```

Do not stop at dictionary generation. Always report:

```text
effective business fields
ACTIVE-covered fields
DRAFT-covered fields
missing-standard-field candidates
unsplit/insufficient-evidence fields
pollution findings
next review batch
```

## Bundled Product Scripts

Prefer bundled scripts over ad hoc project scripts when the task is to run this skill as a reusable product capability.

Available scripts:

- `scripts/UsableDictionaryWriter.java`: initial Dameng-to-ontology writer for base roots, standard fields, mappings, and synonyms. It must honor atomic-root splitting before drafting unknown roots.
- `scripts/DmStandardFieldCoverageAudit.java`: read Dameng metadata and remote ontology dictionaries, then produce coverage, uncovered-field, and uncovered-cluster reports. It is read-only for remote ontology tables.
- `scripts/SkillAssetDraftFieldRepair.java`: read the uncovered-cluster report and skill knowledge assets, then insert missing DRAFT roots, DRAFT standard fields, and INACTIVE root-field maps without modifying existing ACTIVE rows.
- `scripts/ControlledUnsplitDraftRepair.java`: process high-value `UNSPLIT` clusters only when deterministic roots can fully split the phrase; reject platform/technical noise; write DRAFT/INACTIVE only.
- `scripts/UnsplitReviewArtifactExporter.java`: export remaining `UNSPLIT` clusters as LLM/manual review tasks instead of writing risky formal-table rows.
- `scripts/AliyunTokenizerArtifactExporter.java`: call Aliyun NLP `GetWsChGeneral` when credentials are available, or export pending tokenizer rows when credentials are missing.
- `scripts/jieba_tokenizer_candidates.py`: use local `jieba` with skill custom dictionary to create tokenizer candidate artifacts.
- `scripts/jieba_root_whitelist_builder.py`: rank unknown jieba tokens and produce a high-frequency business-root whitelist candidate artifact.
- `scripts/jieba_candidate_draft_writer.py`: conservatively write validated jieba candidates as DRAFT/INACTIVE; default mode only uses existing roots.
- `scripts/jieba_coverage_audit.py`: estimate extra coverage explainable by jieba candidates when deterministic audit cannot split the original phrase.
- `scripts/backfill_governance_fields.py`: backfill `source_type`, `confidence_level`, and `review_note` for existing four-table rows.
- `scripts/validate_dictionary.py`: validate candidate artifacts or exported four-table data for boundary violations.

Default Java classpath dependencies:

```text
DmJdbcDriver18
mysql-connector-j
pinyin4j
```

When running inside a project, copy or compile these scripts from the skill directory, but treat the skill copy as the source of truth. If a project copy diverges, patch the skill copy first, then refresh the project copy.

## Default Dameng -> Ontology Runbook

For the current product workflow:

1. Run coverage audit with `scripts/DmStandardFieldCoverageAudit.java`.
2. Review `dm_uncovered_clusters.csv`; skip `UNSPLIT:*` clusters unless LLM/manual split review is requested.
3. Run `scripts/SkillAssetDraftFieldRepair.java` to fill missing DRAFT standard fields from known root assets.
4. Run `scripts/ControlledUnsplitDraftRepair.java` for deterministic high-value UNSPLIT clusters.
5. Run coverage audit again.
6. Export remaining UNSPLIT clusters with `scripts/UnsplitReviewArtifactExporter.java` for LLM/manual review.
7. Run `scripts/jieba_tokenizer_candidates.py` for local tokenizer evidence. Use Aliyun tokenizer only when credentials or ES analyzer access are available.
8. Validate tokenizer candidates before any formal-table write. Use `scripts/jieba_candidate_draft_writer.py` in existing-root mode by default; `--allow-unknown` is review-mode only and requires immediate root-pollution audit.
9. Use `scripts/jieba_coverage_audit.py` to report tokenizer-assisted coverage separately from deterministic coverage.
10. Run `scripts/backfill_governance_fields.py` after any bulk write so `source_type`, `confidence_level`, and `review_note` are complete.
11. Validate four-table status invariants:
   `ACTIVE` rows unchanged, DRAFT fields have INACTIVE maps, all field segments have roots, no compound roots.
12. Report ACTIVE coverage, ACTIVE+DRAFT coverage, tokenizer-assisted coverage, new DRAFT roots/fields/maps, and top remaining blockers.

LLM-assisted splitting may produce review artifacts, but it must not write formal tables until deterministic validation approves the proposed roots and fields. Do not use fixed-width slicing as a substitute for semantic segmentation.

Safety:

```text
never clear the four tables in this runbook
never update existing ACTIVE rows
new uncertain business coverage goes to DRAFT
map rows for DRAFT fields are INACTIVE
```

## Output Contract

For generation tasks, produce or save a candidate artifact with these fields:

```text
source_schema
source_table
source_table_comment
source_column
source_column_comment
data_type
sample_pattern
semantic_cn
root_codes
root_names
standard_field_code
standard_field_name
confidence_level
decision
evidence_json
reject_reason
review_action
learning_key
```

Every reviewable physical field must have a standard-field candidate. If some Chinese terms are not in the root dictionary, create atomic DRAFT root candidates first, then compose a DRAFT standard field.

The candidate artifact is the learning surface. Use stable `learning_key` values such as:

```text
schema.table.column
semantic_cn
standard_field_code
```

For formal four-table preparation, produce four reviewed artifacts:

```text
om_term_root candidates
om_standard_field candidates
om_root_field_map candidates
om_root_synonym candidates
```

## Validation

Run validation before presenting results as usable:

```bash
python scripts/validate_dictionary.py --roots roots.csv --fields fields.csv --maps maps.csv --synonyms synonyms.csv
```

If artifacts are JSON arrays:

```bash
python scripts/validate_dictionary.py --roots roots.json --fields fields.json --maps maps.json --synonyms synonyms.json
```

Important failures:

- `FORBIDDEN_COMPOUND_ROOT`: known bad field-level compound root.
- `SUSPECT_COMPOUND_ROOT`: root appears to be a field-level compound and needs review.
- `UNKNOWN_FIELD_SEGMENT`: standard field contains a segment not in roots.
- `AUXILIARY_ROOT_USED_IN_FIELD`: abbreviation/helper root used inside a standard field.
- `INCOMPLETE_FIELD_MAP`: field mappings do not cover every segment of a standard field.
- `SYNONYM_POINTS_TO_FIELD`: synonym relation contains a standard field instead of a root.

## Dameng Validation

When validating against a Dameng source, read metadata first and sample values only when needed. Mask sensitive samples. If a project already has a Dameng simulation or coverage script, run it as an independent check and compare these points:

- no forbidden compound roots are generated;
- generic single words are not over-promoted to formal standard fields;
- abbreviation-only fields without confirmed dictionary support remain candidates;
- coverage is measured by physical-field-to-standard-field mapping, not by standard-field count.
- reviewable fields without full ACTIVE-root coverage still produce DRAFT standard-field candidates.
- ACTIVE-only coverage and ACTIVE+DRAFT coverage are reported separately.
- high-frequency uncovered semantics are grouped and proposed as the next review batch.

## Review Standard

Score the result out of 100:

- 30 points: four-table boundary correctness.
- 25 points: root and standard-field splitting correctness.
- 20 points: evidence quality and confidence classification.
- 15 points: coverage logic and semantic clustering.
- 10 points: validation artifacts and reproducibility.

Stop only when the score is 99 or higher, or clearly state the residual blocker.
