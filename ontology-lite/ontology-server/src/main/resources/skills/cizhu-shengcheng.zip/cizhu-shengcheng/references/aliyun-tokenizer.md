# Aliyun Chinese Tokenizer Adapter

Use Alibaba Cloud NLP word segmentation as an evidence source before root generation.

Official capability:

```text
Action: GetWsChGeneral
TokenizerId: GENERAL_CHN
OutType: 1
```

Purpose in this skill:

```text
semantic_cn -> Aliyun tokens -> root normalization -> DRAFT candidate artifact -> validation -> formal table write
```

Rules:

1. Aliyun tokens are evidence, not final roots.
2. Do not write tokenizer output directly to `om_term_root`.
3. Every token must pass root rules: Chinese business word, pinyin code, no field-level phrase, no platform/technical noise.
4. Unknown tokenizer tokens enter DRAFT only after validation.
5. If credentials are missing, export a pending tokenizer input file and stop the tokenizer stage honestly.

Required environment variables:

```text
ALIBABA_CLOUD_ACCESS_KEY_ID
ALIBABA_CLOUD_ACCESS_KEY_SECRET
ALIBABA_CLOUD_REGION_ID   # default cn-hangzhou
```

Security:

Do not hardcode AK/SK into skill files or project code.
