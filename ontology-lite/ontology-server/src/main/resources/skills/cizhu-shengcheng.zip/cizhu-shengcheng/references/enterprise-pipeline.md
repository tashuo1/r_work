# Enterprise Ontology Dictionary Pipeline

## Goal

Generate enterprise-usable ontology dictionaries from business databases with strict term-root purity and practical field coverage.

Success metrics:

```text
ACTIVE business-field coverage >= 70%
ACTIVE + DRAFT reviewable coverage >= 90%
term-root pollution = 0
unknown standard-field segment = 0
DRAFT field with ACTIVE map = 0
```

Coverage denominator is effective business physical fields, not all database columns.

## 1. Scan

Collect:

```text
schema_name
table_name
table_comment
column_name
column_comment
data_type
length/precision/scale
nullable
primary_key/index hints
masked sample_values
distinct_count
null_ratio
top_enum_values
same-table columns
```

Exclude system schemas, temporary/backup/log/cache tables, pure technical columns, and fields whose only meaning is row maintenance.

## 2. Evidence Profile

Build one evidence profile per physical field:

```text
field_name_evidence
column_comment_evidence
table_context_evidence
same_table_context_evidence
sample_shape_evidence
enum_distribution_evidence
conflict_flags
```

Sample values confirm shape only. They cannot override clear business comments.

## 3. Semantic Inference

Infer `semantic_cn` before generating roots.

Levels:

| Level | Meaning | Default Status |
|---|---|---|
| L1 | clear Chinese column comment, not platform metadata | ACTIVE candidate |
| L2 | field name + table context + same-table fields are consistent | DRAFT or ACTIVE after memory confirmation |
| L3 | weak inference from abbreviation, enum, or sample pattern | DRAFT |
| L4 | no reliable business meaning | REJECTED |

Generic words need object context:

```text
名称 编号 编码 日期 时间 状态 类型 标志 标识 金额 数量
```

Example:

```text
STATUS in contract approval table -> 审批状态, DRAFT unless review memory confirms it.
STATUS without object context -> 状态, DRAFT or rejected for formal business modeling.
```

## 4. Root Generation

Load root knowledge in this order:

```text
review-memory.yml
common-roots.yml
domain-roots-*.yml
remote ACTIVE roots
remote DRAFT roots
```

Split `semantic_cn` by longest confirmed root first, then domain roots, then LLM-assisted atomic proposal.

Never create a root from the entire field phrase. If an unknown fragment remains:

```text
single business concept -> create DRAFT root
multi-word fragment -> split or send to PENDING_REVIEW
platform/config fragment -> REJECTED or DRAFT platform candidate
```

## 5. Standard Field Generation

Standard field code:

```text
root1_root2_root3
```

Status:

```text
all roots ACTIVE + L1/AUTO evidence -> ACTIVE
any root DRAFT or evidence L2/L3 -> DRAFT
platform metadata -> REJECTED or DRAFT only when manually allowed
```

Map status:

```text
ACTIVE standard field -> ACTIVE maps
DRAFT standard field -> INACTIVE maps
```

## 6. LLM Role

LLM may propose:

```text
semantic_cn
root split
standard_field_code
similar-field cluster
synonym candidate
review reason
```

LLM must not:

```text
write formal tables directly
modify ACTIVE rows
invent roots without evidence
ignore platform-stopword rules
```

LLM output must be structured and auditable.

## 7. Automatic Audit

Required audits:

```text
term-root pollution
unknown standard-field segment
auxiliary root used in field
incomplete root-field maps
DRAFT/ACTIVE status mismatch
platform metadata leakage
homophone conflicts
duplicate standard fields with same Chinese meaning
coverage by physical-field mapping
high-frequency uncovered semantics
```

Stop a write if hard failures exist.

Homophone rule:

```text
one root_code must represent one Chinese root_name only
```

If two Chinese terms share the same pinyin, do not auto-create both as ACTIVE. Keep the existing ACTIVE meaning, place the conflicting term in `PENDING_REVIEW`, and require a formal disambiguation/migration plan before it can compose ACTIVE standard fields.

## 7.1 Controlled LLM Candidate Split

When a high-frequency `UNSPLIT` semantic remains after deterministic roots, use a controlled LLM-assisted candidate split:

```text
1. Use confirmed roots first.
2. Remove grammatical particles and enum value tails.
3. Unknown fragments may become candidate DRAFT roots only when they are complete 2-4 Chinese-character business words, noun-like, and not a field-level suffix phrase.
4. Never create one root from the whole semantic phrase.
5. If the phrase is a report line item, financial metric, or long domain indicator, first create a review artifact, not formal-table rows.
6. If the phrase is platform/config/technical/log text, reject it from the business denominator.
```

LLM-assisted candidates must pass deterministic validation before writing any formal table. Bad fragment examples such as `十二未分`, `减应付普`, `号填列本`, `二将重分`, or any fragment created by arbitrary fixed-width slicing are forbidden.

This is the enterprise coverage mechanism: strict roots for ACTIVE, broad but reviewable candidate artifacts for business coverage, explicit rejection for non-business noise, and formal-table writes only after validation.

## 8. Review Batch

Sort manual review candidates by business value:

```text
physical field frequency
schema/table importance
semantic cluster size
sample/enum clarity
downstream query value
```

Recommended review actions:

```text
PROMOTE_ROOT
PROMOTE_FIELD
SPLIT_OVERRIDE
MERGE_SYNONYM
REJECT_PLATFORM
REJECT_TECHNICAL
NEEDS_BUSINESS_OWNER
```

## 9. Learning Loop

After manual review, write decisions into `review-memory.yml` or project-specific memory.

Memory can contain:

```text
confirmed_roots
confirmed_standard_fields
rejected_semantics
split_overrides
abbreviation_expansions
synonym_decisions
platform_allowed_tables
```

Next run must load memory before generic rules. Memory cannot change existing ACTIVE data unless the user explicitly asks for migration.

## 10. In-Table Candidate Governance

Do not create separate candidate tables unless the project explicitly requests them. Candidate governance is represented inside the existing formal tables:

```text
om_term_root.status = ACTIVE / DRAFT / REJECTED
om_standard_field.status = ACTIVE / DRAFT / REJECTED
om_root_field_map.status = ACTIVE / INACTIVE
```

Additional governance fields on `om_term_root` and `om_standard_field`:

```text
source_type        RULE / JIEBA / LLM / MANUAL
confidence_level   AUTO / L1 / L2 / L3 / CANDIDATE_HIGH / CANDIDATE_LOW / PENDING_REVIEW
evidence_json      source evidence, tokenizer tokens, sample fields, enum values
review_note        human-readable reason and next action
```

Rules:

```text
ACTIVE = confirmed usable dictionary data
DRAFT = candidate carried in formal table for review and coverage
REJECTED = retained negative decision, not used for generation
INACTIVE map = relationship for DRAFT field or non-effective candidate
```
