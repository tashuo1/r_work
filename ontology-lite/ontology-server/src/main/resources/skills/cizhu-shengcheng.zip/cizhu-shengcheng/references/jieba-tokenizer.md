# Jieba Tokenizer Adapter

Use `jieba` as the default free local tokenizer for Chinese business semantics.

Role:

```text
semantic_cn -> jieba tokens with skill custom dictionary -> root-rule filter -> candidate artifact -> validation -> optional DRAFT write
```

Rules:

1. Load `common-roots.yml`, `domain-roots-*.yml`, and remote roots as custom dictionary words before tokenization.
2. Jieba tokens are evidence, not final roots.
3. Never write a token directly to `om_term_root` unless it passes root rules.
4. Reject platform, technical, enum-tail, and fixed-width fragments.
5. Candidate output must include token evidence and reject reason.
6. Formal-table writes are allowed only after candidate validation.
7. Default write mode must use existing roots only.
8. `--allow-unknown` is a review-mode option. Use it only for bounded batches, then audit newly inserted DRAFT roots before continuing.
9. Build a high-frequency whitelist candidate file before allowing unknown tokens to become DRAFT roots.
10. Unknown tokenizer tokens whose Chinese length is 1 or 2 are written as `ACTIVE` roots after validation. Unknown tokens longer than 2 Chinese characters remain `DRAFT` unless review memory confirms them.

Known risk:

```text
jieba may produce boundary-unstable tokens such as 次本, 率本, 上月底.
```

These are allowed only as DRAFT review candidates and must not be promoted without human confirmation.

Install:

```bash
python -m pip install jieba
```
