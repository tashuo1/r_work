# Report Metric Modeling

Use this reference for finance/report-line fields such as balance sheets, profit statements, cash-flow statements, and state-owned-assets reporting forms.

Problem:

```text
report metric fields are often long indicator names, not ordinary master-data attributes
```

Rule:

```text
report metric field = metric subject roots + period/comparison roots + measure roots
```

Examples:

```text
货币资金期末余额 -> huobi_zijin_qimo_yue
应收账款期初余额 -> yingshou_zhangkuan_qichu_yue
销售费用本年累计 -> xiaoshou_feiyong_ben_nian_leiji
固定资产减值准备期末余额 -> gudingzichan_jianzhi_zhunbei_qimo_yue
```

Do not create roots from row numbers, form instructions, or fill hints:

```text
以号
填列
年数
栏次
十大
一/二/三/四/五/六/七/八/九/十/十一/十二 as report row prefixes
```

Status:

```text
report metric standard fields default to DRAFT
maps default to INACTIVE
promote only after business review
```

Coverage:

Report metric fields count toward business coverage when they have clear Chinese metric meaning. Platform/report configuration fields do not.
