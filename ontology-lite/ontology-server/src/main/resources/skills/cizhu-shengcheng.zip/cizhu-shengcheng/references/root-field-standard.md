# 词根与标准字段工程规范

## 四表边界

| 表 | 只允许 | 禁止 |
|---|---|---|
| `om_term_root` | 单一中文业务词的完整小写拼音 | 标准字段、英文缩写、源库字段名、字段级复合词 |
| `om_standard_field` | 已登记规范词根的 `_` 组合 | 未登记词根、英文 snake_case、源库字段名 |
| `om_root_field_map` | 词根参与标准字段构成或辅助识别的关系 | 词根到词根的同义关系 |
| `om_root_synonym` | 主词根到关联词根的同义、近义、缩略关系 | 标准字段、源字段、表名、对象名 |

## ACTIVE 数据保护

`ACTIVE` 数据视为已生效主数据，默认不可修改。

禁止在常规生成、重跑、候选补全、状态刷新流程中对 `ACTIVE` 行执行：

```text
UPDATE
DELETE
覆盖写入
降级为 DRAFT/INACTIVE
重新生成覆盖
```

允许的操作：

```text
1. 新增不存在的 DRAFT/ACTIVE 行。
2. 更新 DRAFT/INACTIVE 行。
3. 当 DRAFT 标准字段的全部组成词根已为 ACTIVE，可将该标准字段升为 ACTIVE。
4. 当 DRAFT 标准字段升为 ACTIVE，可将其组成映射从 INACTIVE 升为 ACTIVE。
```

前提：

```text
不得修改任何已经是 ACTIVE 的词根、标准字段、映射、同义词记录。
```

## 候选治理字段

候选治理不单独建表时，四表通过状态与证据字段承载审核闭环。

`om_term_root` 与 `om_standard_field` 应支持：

```text
source_type
confidence_level
evidence_json
review_note
```

状态含义：

| 状态 | 含义 |
|---|---|
| `ACTIVE` | 已确认可正式使用 |
| `DRAFT` | 候选，可用于覆盖率和人工审核，不代表已正式确认 |
| `REJECTED` | 明确拒绝，保留负样本，避免反复生成 |

`DRAFT` 标准字段的 `om_root_field_map.status` 必须为 `INACTIVE`。

## 词根规则

词根是中文业务词的汉语拼音，必须是单一语义单元。

禁止将完整字段口径作为词根。字段级后缀包括：

```text
时间 日期 名称 编号 编码 类型 状态 金额 号码 代码 标志 标识 标题 说明 地址 定义 模板 数据 条件 依据 时机 值
次数 率 行数 原因 参数 结果 消息 内容 耗时 总数
描述 方案 单位 规则 对象 主键 表名 字段 映射 注释 队列 流程 节点 权限 缓存 索引 路径 顺序 序号 范围 方式 记录数 字节 长度 大小 收入 支出 利润 余额 总额
```

如果中文含义是“主体词 + 属性词”，必须拆为多个词根并生成标准字段：

| 错误词根 | 正确词根 | 正确标准字段 |
|---|---|---|
| `yonghuleixing` | `yonghu` + `leixing` | `yonghu_leixing` |
| `xiugaishijian` | `xiugai` + `shijian` | `xiugai_shijian` |
| `fujibiaoshi` | `fuji` + `biaoshi` | `fuji_biaoshi` |
| `moxingbiaoshi` | `moxing` + `biaoshi` | `moxing_biaoshi` |
| `biaobiaoshi` | `biao` + `biaoshi` | 默认不入正式业务字段 |
| `mubiaobiaodingyi` | `mubiao` + `biao` + `dingyi` | 平台元数据，默认拒绝 |
| `qingqiucishu` | `qingqiu` + `cishu` | `qingqiu_cishu` |
| `chenggongcishu` | `chenggong` + `cishu` | `chenggong_cishu` |
| `shibaicishu` | `shibai` + `cishu` | `shibai_cishu` |
| `chenggonglv` | `chenggong` + `lv` | `chenggong_lv` |
| `caozuomiaoshu` | `caozuo` + `miaoshu` | `caozuo_miaoshu` |
| `ziduanyingshe` | `ziduan` + `yingshe` | 平台元数据，默认拒绝 |
| `xiaoxiduilie` | `xiaoxi` + `duilie` | 平台/技术字段，默认拒绝 |

例外只允许稳定权威术语，如“身份证”“营业执照”。例外必须有中文定义和人工确认。

## 标准字段规则

标准字段必须由规范词根组成：

```text
标准字段 = 词根1 + "_" + 词根2 + ... + 词根N
```

标准字段每一段都必须存在于 `om_term_root`，且不得使用辅助识别词根。

## 候选闭环规则

不能为了词根纯净度丢弃可识别字段。

当字段中文语义清晰，但无法完全拆成已登记 `ACTIVE` 词根时，必须按以下规则处理：

```text
1. 先拆出已知原子词根。
2. 未知部分不得整体作为复合词根。
3. 未知部分如果是可审查的单一中文词，生成 DRAFT 词根。
4. 用 ACTIVE + DRAFT 词根组成 DRAFT 标准字段。
5. om_root_field_map 写 INACTIVE。
6. biz_definition 写清楚来源、证据和待确认原因。
```

示例：

| 中文字段 | 错误处理 | 正确处理 |
|---|---|---|
| 报表方案 | 词根 `baobiaofangan` 或直接丢弃 | `baobiao(DRAFT)` + `fangan(ACTIVE)` -> `baobiao_fangan(DRAFT)` |
| 字段映射 | 词根 `ziduanyingshe` | `ziduan` + `yingshe` -> `ziduan_yingshe(DRAFT/platform)` |
| 操作描述 | 词根 `caozuomiaoshu` | `caozuo` + `miaoshu` -> `caozuo_miaoshu` |

状态规则：

| 对象 | ACTIVE | DRAFT |
|---|---|---|
| 词根 | 已确认原子词 | 待确认原子词 |
| 标准字段 | 已确认字段口径 | 待确认字段候选 |
| 映射 | ACTIVE 标准字段组成关系 | DRAFT 标准字段组成关系，状态必须为 INACTIVE |

短词根直通规则：

```text
分词器或 LLM 识别出的未知原子词根，若中文 root_name 长度 <= 2，且通过词根边界校验，可直接写为 ACTIVE。
中文 root_name 长度 > 2 的未知词根默认写 DRAFT，除非 review-memory 已明确确认。
该规则只适用于 om_term_root，不自动提升 om_standard_field。
```

平台/技术类字段不进入业务 ACTIVE，但可以作为 DRAFT 候选保留，供平台域或人工审核使用。

## 两层词根体系

先用基础通用词根，再补业务域词根。

基础通用词根包括但不限于：

```text
riqi shijian nian yue ri kaishi jieshu chuangjian gengxin xiugai zuihou
bianhao bianma daima haoma biaoshi biaozhi
mingcheng biaoti leixing leibie zhuangtai dengji shuoming beizhu
jine shuliang danjia shuier bili lilv bizhong bibie huobi
shouji dianhua youxiang dizhi
yonghu renyuan yuangong zuzhi bumen gangwei
caozuo shenhe queren shengxiao shixiao zhibiao zhi
cishu lv xingshu yuanyin canshu jieguo xiaoxi neirong haoshi zongshu
qingqiu chenggong shibai zhixing zhongshi chufa shiyong biangeng cuowu dayin chuxian
miaoshu fangan danwei guize duixiang zhujian biaoming ziduan yingshe zhushi duilie liucheng jiedian quanxian huancun suoyin lujing shunxu xuhao fanwei fangshi jilushu zijie zhangdu daxiao shouru zhichu lirun zonge
```

业务域词根来自字段证据链，必须不能被已有基础词根完整表达。

多音/同音编码冲突必须显式消歧。当前约定：

```text
时间 -> shijian
事件 -> 与“时间”同拼音，不能自动进入正式词根；进入候选评审
```

如后续引入正式拼音消歧方案，应统一迁移；在未冻结方案前，不允许一个 `root_code` 同时表示两个中文词，也不允许用数字临时拼接。

## 平台元数据过滤

以下字段即使有中文注释，也默认不是业务标准字段：

```text
表标识 表标题 表定义 目标表 源表 目标表定义 源表定义
关联模板 定义数据 适应条件 生单时机 配置节点 审批节点 表单分类
配置 设置 模板 按钮控制
标准字段 字段映射 字段注释 字段分组 字段排序 字段长度 字段顺序
表结构 表名 接口字段 对象主键 消息队列 流程实例 流程节点
权限描述 菜单图标 同步缓存 索引 租户服务 服务节点 模型 任务 日志 审计
```

处理方式：

- 默认 `REJECTED` 或 `PENDING_REVIEW`。
- 只有人工确认该表就是业务对象时，才允许进入候选。
- 不得把这些短语整体转拼音写入 `om_term_root`。

## 证据链

字段语义必须综合判断：

```text
字段名证据 + 样例值证据 + 表上下文证据 + 同表字段证据
```

样例值只验证数据形态，不能单独决定业务口径。例如 `RQ` 的样例是日期，只能说明它是日期形态，不能自动判定为创建日期、业务日期或付款日期。

## 候选等级

| 等级 | 含义 | 是否可写正式四表 |
|---|---|---|
| `AUTO` | 中文语义明确、可拆词根、通过硬校验 | 可以 |
| `CANDIDATE_HIGH` | 多证据一致但仍需业务确认 | 不直接写入 |
| `CANDIDATE_LOW` | 证据不足或仅弱推断 | 不直接写入 |
| `PENDING_REVIEW` | 歧义、冲突、需要人工判断 | 不写入 |
| `REJECTED` | 技术字段、无业务含义、违反规则 | 不写入 |

工程落库解释：

```text
不直接写入 = 不写 ACTIVE；
如字段语义清楚且可审查，应写 DRAFT/INACTIVE，而不是丢弃。
```

## 覆盖率

错误：

```text
覆盖率 = 标准字段数量 / 物理字段数量
```

正确：

```text
覆盖率 = 已映射到标准字段的有效业务物理字段数 / 有效业务物理字段总数
```

四张正式词典表不能完整承载物理字段映射证据。工程实现必须保留候选映射表或审核文件。

在当前只有四张表可用时，DRAFT 标准字段就是最低限度的候选承载方式。后续应补充物理字段到标准字段的候选映射表。

## 红线

- 不得为了覆盖率把字段整体转拼音写入词根。
- 不得把标准字段去掉下划线反造词根。
- 不得把 `NEAR` 当成完全等价自动合并字段口径。
- 不得把缩写词根用于标准字段组成。
- 不得让无中文注释、无缩写词典、无可靠上下文的字段进入 `ACTIVE`。
- 不得把未识别的 2~4 个汉字短语整体写入 `om_term_root`；必须能拆成已知词根，或者进入候选/拒绝。
- 不得因为缺少已确认词根就丢弃可识别字段；必须生成 DRAFT 原子词根和 DRAFT 标准字段候选。
