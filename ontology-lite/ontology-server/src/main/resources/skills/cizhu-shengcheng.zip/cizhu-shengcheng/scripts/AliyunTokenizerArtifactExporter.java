import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class AliyunTokenizerArtifactExporter {
    private static final Path INPUT = Path.of("tools", "review_out", "unsplit_review_candidates.csv");
    private static final Path OUT = Path.of("tools", "review_out", "aliyun_tokenizer_candidates.csv");
    private static final String ENDPOINT = "https://alinlp.cn-hangzhou.aliyuncs.com/";
    private static final int LIMIT = 500;

    public static void main(String[] args) throws Exception {
        String ak = env("ALIBABA_CLOUD_ACCESS_KEY_ID", "ALIYUN_ACCESS_KEY_ID");
        String sk = env("ALIBABA_CLOUD_ACCESS_KEY_SECRET", "ALIYUN_ACCESS_KEY_SECRET");
        Files.createDirectories(OUT.getParent());
        List<Row> rows = loadRows();
        try (BufferedWriter w = Files.newBufferedWriter(OUT, StandardCharsets.UTF_8)) {
            w.write("semantic_cn,count,category,tokenizer_status,tokens,reject_reason,sample\n");
            if (ak.isBlank() || sk.isBlank()) {
                for (Row r : rows) {
                    w.write(csv(r.semantic) + "," + r.count + "," + r.category + ",PENDING_CREDENTIALS,\"\",\"missing Aliyun AK/SK\"," + csv(r.sample) + "\n");
                }
                System.out.println("TOKENIZER_STATUS=PENDING_CREDENTIALS");
                System.out.println("OUT=" + OUT);
                return;
            }
            HttpClient client = HttpClient.newHttpClient();
            int done = 0;
            for (Row r : rows) {
                String status = "OK";
                String tokens;
                String reason = "";
                try {
                    tokens = callAliyun(client, ak, sk, r.semantic);
                } catch (Exception e) {
                    status = "ERROR";
                    tokens = "";
                    reason = e.getClass().getSimpleName() + ":" + e.getMessage();
                }
                w.write(csv(r.semantic) + "," + r.count + "," + r.category + "," + status + "," + csv(tokens) + "," + csv(reason) + "," + csv(r.sample) + "\n");
                done++;
            }
            System.out.println("TOKENIZER_STATUS=OK");
            System.out.println("ROWS=" + done);
            System.out.println("OUT=" + OUT);
        }
    }

    private static List<Row> loadRows() throws Exception {
        List<Row> out = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(INPUT, StandardCharsets.UTF_8)) {
            String header = r.readLine();
            String line;
            while ((line = r.readLine()) != null && out.size() < LIMIT) {
                List<String> cols = parseCsv(line);
                if (cols.size() < 6) continue;
                String category = cols.get(2);
                if ("TECH_PLATFORM".equals(category)) continue;
                Row row = new Row();
                row.semantic = cols.get(0);
                row.count = Integer.parseInt(cols.get(1));
                row.category = category;
                row.sample = cols.get(5);
                out.add(row);
            }
        }
        return out;
    }

    private static String callAliyun(HttpClient client, String ak, String sk, String text) throws Exception {
        Map<String, String> p = new TreeMap<>();
        p.put("Action", "GetWsChGeneral");
        p.put("Format", "JSON");
        p.put("Version", "2020-06-29");
        p.put("AccessKeyId", ak);
        p.put("SignatureMethod", "HMAC-SHA1");
        p.put("Timestamp", DateTimeFormatter.ISO_INSTANT.format(Instant.now().atOffset(ZoneOffset.UTC)));
        p.put("SignatureVersion", "1.0");
        p.put("SignatureNonce", UUID.randomUUID().toString());
        p.put("ServiceCode", "alinlp");
        p.put("TokenizerId", "GENERAL_CHN");
        p.put("OutType", "1");
        p.put("Text", text);
        String canonical = canonical(p);
        String stringToSign = "GET&%2F&" + percent(canonical);
        String signature = sign(stringToSign, sk + "&");
        String url = ENDPOINT + "?" + canonical + "&Signature=" + percent(signature);
        HttpRequest req = HttpRequest.newBuilder(URI.create(url)).GET().build();
        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (resp.statusCode() >= 300) throw new IllegalStateException("HTTP " + resp.statusCode() + " " + resp.body());
        return resp.body();
    }

    private static String canonical(Map<String, String> p) {
        List<String> parts = new ArrayList<>();
        for (Map.Entry<String, String> e : p.entrySet()) parts.add(percent(e.getKey()) + "=" + percent(e.getValue()));
        return String.join("&", parts);
    }

    private static String percent(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20").replace("*", "%2A").replace("%7E", "~");
    }

    private static String sign(String text, String key) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA1"));
        return Base64.getEncoder().encodeToString(mac.doFinal(text.getBytes(StandardCharsets.UTF_8)));
    }

    private static String env(String a, String b) {
        String x = System.getenv(a);
        if (x != null && !x.isBlank()) return x.trim();
        x = System.getenv(b);
        return x == null ? "" : x.trim();
    }

    private static List<String> parseCsv(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean quote = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (quote && i + 1 < line.length() && line.charAt(i + 1) == '"') { sb.append('"'); i++; }
                else quote = !quote;
            } else if (ch == ',' && !quote) {
                out.add(sb.toString()); sb.setLength(0);
            } else sb.append(ch);
        }
        out.add(sb.toString());
        return out;
    }

    private static String csv(String s) {
        return "\"" + (s == null ? "" : s.replace("\"", "\"\"")) + "\"";
    }

    static class Row {
        String semantic, category, sample;
        int count;
    }
}
