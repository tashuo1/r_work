import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

public class ControlledUnsplitDraftRepair {

    private static String getenv(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }
    private static final String MYSQL_URL = getenv("CIZHU_MYSQL_URL", "jdbc:mysql://127.0.0.1:3306/ontology_meta?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&rewriteBatchedStatements=true");
    private static final String MYSQL_USER = getenv("CIZHU_MYSQL_USER", "root");
    private static final String MYSQL_PASS = getenv("CIZHU_MYSQL_PASSWORD", "");
    private static final long TENANT_ID = 1L;
    private static final Path SKILL_REF = Path.of(getenv("CIZHU_SKILL_HOME", "."), "references");
    private static final Path CLUSTERS = Path.of("tools", "review_out", "dm_uncovered_clusters.csv");

    private static final Set<String> REJECT_PATTERNS = Set.of(
            "短文本", "父事务", "交换器", "客户端", "数据流", "主表", "编排版本号", "行版本", "报表或分组",
            "整数", "操作用户用户名", "操作人信息", "最后操作人", "创建人"
    );
    private static final Set<String> NOISE_TOKENS = Set.of("是否", "已", "是", "否", "的", "或", "和", "及", "与", "第", "一");

    static class Root {
        String code, name, domain, status;
        Root(String c, String n, String d, String s) { code = c; name = n; domain = d; status = s; }
    }

    static class Cluster {
        String semantic, sample;
        int count;
    }

    public static void main(String[] args) throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Map<String, Root> skillRoots = loadSkillRoots();
        List<String> rootNames = new ArrayList<>();
        for (Root r : skillRoots.values()) rootNames.add(r.name);
        rootNames.sort((a, b) -> Integer.compare(b.length(), a.length()));
        List<Cluster> clusters = loadUnsplitClusters();
        try (Connection c = DriverManager.getConnection(MYSQL_URL, MYSQL_USER, MYSQL_PASS)) {
            c.setAutoCommit(false);
            Map<String, Root> remoteRoots = loadRemoteRoots(c);
            Map<String, Long> rootIds = loadIds(c, "om_term_root", "root_code");
            Map<String, Long> fieldIds = loadIds(c, "om_standard_field", "field_code");
            int rootInserted = 0, fieldInserted = 0, mapInserted = 0, rejected = 0, unresolved = 0;

            for (Cluster cluster : clusters) {
                if (shouldReject(cluster.semantic)) {
                    rejected += cluster.count;
                    continue;
                }
                List<Root> roots = split(cluster.semantic, rootNames, skillRoots, remoteRoots);
                if (roots.size() < 2 || roots.size() > 10) {
                    unresolved += cluster.count;
                    continue;
                }
                String fieldCode = joinCodes(roots);
                if (!fieldCode.matches("[a-z]+(_[a-z]+)*") || fieldCode.length() > 128) {
                    unresolved += cluster.count;
                    continue;
                }
                for (Root root : roots) {
                    if (!rootIds.containsKey(root.code)) {
                        long id = insertDraftRoot(c, root);
                        rootIds.put(root.code, id);
                        remoteRoots.put(root.code, new Root(root.code, root.name, root.domain, "DRAFT"));
                        rootInserted++;
                    }
                }
                Long fieldId = fieldIds.get(fieldCode);
                if (fieldId == null) {
                    fieldId = insertDraftField(c, fieldCode, roots, cluster);
                    fieldIds.put(fieldCode, fieldId);
                    fieldInserted++;
                }
                for (Root root : roots) {
                    Long rootId = rootIds.get(root.code);
                    if (rootId != null && insertInactiveMap(c, rootId, fieldId)) mapInserted++;
                }
            }
            c.commit();
            System.out.println("UNSPLIT_CLUSTERS_READ=" + clusters.size());
            System.out.println("DRAFT_ROOTS_INSERTED=" + rootInserted);
            System.out.println("DRAFT_FIELDS_INSERTED=" + fieldInserted);
            System.out.println("INACTIVE_MAPS_INSERTED=" + mapInserted);
            System.out.println("REJECTED_FIELD_COUNT=" + rejected);
            System.out.println("UNRESOLVED_FIELD_COUNT=" + unresolved);
        }
    }

    private static boolean shouldReject(String s) {
        for (String p : REJECT_PATTERNS) if (s.contains(p)) return true;
        if (s.contains("状态") && s.length() > 6) return true;
        if (s.contains("标识") && s.length() > 8 && !s.matches(".*(方案|凭证|项目|合同|客户|组织).*")) return true;
        return false;
    }

    private static List<Root> split(String semantic, List<String> rootNames, Map<String, Root> skillRoots, Map<String, Root> remoteRoots) {
        String rest = semantic;
        List<Root> out = new ArrayList<>();
        while (!rest.isBlank()) {
            boolean removedNoise = false;
            for (String noise : NOISE_TOKENS) {
                if (rest.startsWith(noise)) {
                    rest = rest.substring(noise.length());
                    removedNoise = true;
                    break;
                }
            }
            if (removedNoise) continue;
            Root hitRoot = null;
            String hitName = "";
            for (String name : rootNames) {
                if (rest.startsWith(name)) {
                    hitName = name;
                    hitRoot = findByName(name, skillRoots, remoteRoots);
                    break;
                }
            }
            if (hitRoot == null) return List.of();
            out.add(hitRoot);
            rest = rest.substring(hitName.length());
        }
        return out;
    }

    private static Root findByName(String name, Map<String, Root> skillRoots, Map<String, Root> remoteRoots) {
        for (Root r : remoteRoots.values()) if (name.equals(r.name)) return r;
        for (Root r : skillRoots.values()) if (name.equals(r.name)) return r;
        return null;
    }

    private static String joinCodes(List<Root> roots) {
        List<String> codes = new ArrayList<>();
        for (Root r : roots) codes.add(r.code);
        return String.join("_", codes);
    }

    private static Map<String, Root> loadSkillRoots() throws Exception {
        Map<String, Root> roots = new LinkedHashMap<>();
        loadSkillRootsFile(roots, SKILL_REF.resolve("common-roots.yml"), "common");
        loadSkillRootsFile(roots, SKILL_REF.resolve("domain-roots-finance.yml"), "finance");
        loadSkillRootsFile(roots, SKILL_REF.resolve("domain-roots-hr.yml"), "hr");
        loadSkillRootsFile(roots, SKILL_REF.resolve("domain-roots-investment.yml"), "investment");
        return roots;
    }

    private static void loadSkillRootsFile(Map<String, Root> roots, Path path, String fallbackDomain) throws Exception {
        if (!Files.exists(path)) return;
        Pattern codeP = Pattern.compile("code:\\s*([^,} ]+)");
        Pattern nameP = Pattern.compile("name:\\s*([^,} ]+)");
        Pattern domainP = Pattern.compile("domain:\\s*([^,} ]+)");
        for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
            var codeM = codeP.matcher(line);
            var nameM = nameP.matcher(line);
            if (!codeM.find() || !nameM.find()) continue;
            String code = codeM.group(1).trim();
            String name = nameM.group(1).trim();
            if (!code.matches("[a-z]+") || name.isBlank()) continue;
            var domainM = domainP.matcher(line);
            String domain = domainM.find() ? domainM.group(1).trim() : fallbackDomain;
            roots.putIfAbsent(code, new Root(code, name, domain, "DRAFT"));
        }
    }

    private static List<Cluster> loadUnsplitClusters() throws Exception {
        List<Cluster> out = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(CLUSTERS, StandardCharsets.UTF_8)) {
            r.readLine();
            String line;
            while ((line = r.readLine()) != null) {
                List<String> cols = parseCsv(line);
                if (cols.size() < 4 || !cols.get(0).startsWith("UNSPLIT:")) continue;
                Cluster c = new Cluster();
                c.semantic = cols.get(0).substring("UNSPLIT:".length());
                c.count = Integer.parseInt(cols.get(1));
                c.sample = cols.get(3);
                out.add(c);
            }
        }
        out.sort((a, b) -> Integer.compare(b.count, a.count));
        return out;
    }

    private static Map<String, Root> loadRemoteRoots(Connection c) throws SQLException {
        Map<String, Root> out = new LinkedHashMap<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT root_code, root_name, domain_name, status FROM om_term_root WHERE tenant_id=?")) {
            ps.setLong(1, TENANT_ID);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.put(rs.getString(1), new Root(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
        }
        return out;
    }

    private static Map<String, Long> loadIds(Connection c, String table, String codeCol) throws SQLException {
        Map<String, Long> out = new LinkedHashMap<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT id," + codeCol + " FROM " + table + " WHERE tenant_id=?")) {
            ps.setLong(1, TENANT_ID);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.put(rs.getString(2), rs.getLong(1));
            }
        }
        return out;
    }

    private static long insertDraftRoot(Connection c, Root root) throws SQLException {
        String sql = "INSERT INTO om_term_root (tenant_id, root_code, root_name, biz_definition, domain_name, status) VALUES (?,?,?,?,?,'DRAFT')";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, TENANT_ID);
            ps.setString(2, root.code);
            ps.setString(3, root.name);
            ps.setString(4, "待确认词根：" + root.name + "；来源：受控 UNSPLIT 聚类拆分；状态：待人工确认");
            ps.setString(5, root.domain);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) return rs.getLong(1); }
        }
        throw new SQLException("no generated key for root " + root.code);
    }

    private static long insertDraftField(Connection c, String fieldCode, List<Root> roots, Cluster cluster) throws SQLException {
        String name = roots.stream().map(r -> r.name).reduce("", String::concat);
        String definition = "口径：" + name + "；来源：达梦 UNSPLIT 高价值聚类；生成方式：CONTROLLED_UNSPLIT_DRAFT；置信状态：待确认；覆盖物理字段数：" + cluster.count + "；样例：" + trim(cluster.sample, 120);
        String sql = "INSERT INTO om_standard_field (tenant_id, field_code, field_name, field_type, biz_definition, combo_key, status) VALUES (?,?,?,?,?,?,'DRAFT')";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, TENANT_ID);
            ps.setString(2, fieldCode);
            ps.setString(3, name);
            ps.setString(4, "STRING");
            ps.setString(5, trim(definition, 500));
            ps.setString(6, "unsplit_draft_" + fieldCode);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) return rs.getLong(1); }
        }
        throw new SQLException("no generated key for field " + fieldCode);
    }

    private static boolean insertInactiveMap(Connection c, long rootId, long fieldId) throws SQLException {
        String sql = "INSERT IGNORE INTO om_root_field_map (tenant_id, root_id, standard_field_id, relation_type, weight_score, status) VALUES (?,?,?,'SYNONYM',1.00,'INACTIVE')";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, TENANT_ID);
            ps.setLong(2, rootId);
            ps.setLong(3, fieldId);
            return ps.executeUpdate() > 0;
        }
    }

    private static List<String> parseCsv(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean quote = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (quote && i + 1 < line.length() && line.charAt(i + 1) == '"') { sb.append('"'); i++; }
                else quote = !quote;
            } else if (ch == ',' && !quote) {
                out.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(ch);
            }
        }
        out.add(sb.toString());
        return out;
    }

    private static String trim(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 3) + "...";
    }
}
