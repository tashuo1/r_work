import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;

import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

public class DmStandardFieldCoverageAudit {

    private static String getenv(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }
    private static final String DM_URL = getenv("CIZHU_DM_URL", "jdbc:dm://127.0.0.1:5236");
    private static final String DM_USER = getenv("CIZHU_DM_USER", "SYSDBA");
    private static final String DM_PASS = getenv("CIZHU_DM_PASSWORD", "");
    private static final String MYSQL_URL = getenv("CIZHU_MYSQL_URL", "jdbc:mysql://127.0.0.1:3306/ontology_meta?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false");
    private static final String MYSQL_USER = getenv("CIZHU_MYSQL_USER", "root");
    private static final String MYSQL_PASS = getenv("CIZHU_MYSQL_PASSWORD", "");
    private static final Path SKILL_REF = Path.of(getenv("CIZHU_SKILL_HOME", "."), "references");

    private static final Set<String> SYS_OWNERS = Set.of("SYS", "SYSTEM", "SYSAUDITOR", "SYSSSO", "SYSDBA", "CTISYS", "DMHS", "DMSYS", "SYSJOB");
    private static final Pattern TECH_COL = Pattern.compile("(?i)^(id|row_id|uuid|guid|dr|ts|sort|version|tenant_id|trace_id|request_id|del_flag|delete_flag|is_deleted|create_by|created_by|update_by|updated_by)$");
    private static final Pattern BAD_TABLE = Pattern.compile("(?i).*(temp|tmp|bak|backup|log|audit|cache|snapshot).*");
    private static final Set<String> PLATFORM_WORDS = new LinkedHashSet<>(Arrays.asList(
            "表标题", "表类型", "表定义", "目标表", "源表", "关联模板", "字段映射", "字段注释", "字段排序", "字段长度",
            "配置节点", "审批节点", "表单分类", "按钮控制", "流程节点", "消息队列", "同步缓存", "菜单图标", "任务日志"
    ));
    private static final Map<String, String> EN_DICT = new HashMap<>();

    static {
        String[][] en = {
                {"NAME", "名称"}, {"MC", "名称"}, {"TITLE", "标题"}, {"CODE", "编码"}, {"BM", "编码"}, {"NO", "编号"}, {"BH", "编号"},
                {"DATE", "日期"}, {"RQ", "日期"}, {"TIME", "时间"}, {"CREATETIME", "创建时间"}, {"CREATE_TIME", "创建时间"},
                {"UPDATETIME", "更新时间"}, {"UPDATE_TIME", "更新时间"}, {"AMOUNT", "金额"}, {"AMT", "金额"}, {"JE", "金额"},
                {"MONEY", "金额"}, {"STATUS", "状态"}, {"STATE", "状态"}, {"TYPE", "类型"}, {"FLAG", "标志"},
                {"PHONE", "电话"}, {"MOBILE", "手机"}, {"EMAIL", "邮箱"}, {"ADDRESS", "地址"}, {"ADDR", "地址"},
                {"REMARK", "备注"}, {"BZ", "备注"}
        };
        for (String[] e : en) EN_DICT.put(e[0], e[1]);
    }

    static class Col {
        String owner, tableName, tableComment, columnName, columnComment, dataType;
    }

    static class FieldRow {
        String code, name, status;
    }

    static class AuditRow {
        Col col;
        String semanticCn = "";
        String fieldCode = "";
        String fieldName = "";
        String matchStatus = "UNMAPPED";
        String reason = "";
        boolean business = false;
        boolean platform = false;
        boolean exactStandard = false;
        String standardStatus = "";
    }

    public static void main(String[] args) throws Exception {
        Class.forName("dm.jdbc.driver.DmDriver");
        Class.forName("com.mysql.cj.jdbc.Driver");

        List<Col> columns = readDmColumns();
        Map<String, FieldRow> standardFields = readStandardFields();
        Map<String, String> roots = readRoots();
        loadSkillRoots(roots, SKILL_REF.resolve("common-roots.yml"));
        loadSkillRoots(roots, SKILL_REF.resolve("domain-roots-finance.yml"));
        loadSkillRoots(roots, SKILL_REF.resolve("domain-roots-hr.yml"));
        loadSkillRoots(roots, SKILL_REF.resolve("domain-roots-investment.yml"));
        List<String> rootNames = new ArrayList<>(new LinkedHashSet<>(roots.values()));
        loadPlatformTerms();
        addFallbackTerms(rootNames);
        rootNames.sort((a, b) -> Integer.compare(b.length(), a.length()));

        List<AuditRow> rows = new ArrayList<>();
        for (Col col : columns) {
            AuditRow row = audit(col, rootNames, standardFields);
            rows.add(row);
        }

        Path outDir = Path.of("tools", "review_out");
        Files.createDirectories(outDir);
        writeCsv(outDir.resolve("dm_standard_coverage.csv"), rows, false);
        writeCsv(outDir.resolve("dm_standard_uncovered.csv"), rows, true);
        writeClusters(outDir.resolve("dm_uncovered_clusters.csv"), rows);
        printSummary(rows);
    }

    private static List<Col> readDmColumns() throws SQLException {
        String sql = """
                SELECT c.OWNER, c.TABLE_NAME, tc.COMMENTS AS TABLE_COMMENT,
                       c.COLUMN_NAME, cc.COMMENTS AS COLUMN_COMMENT, c.DATA_TYPE
                FROM ALL_TAB_COLUMNS c
                LEFT JOIN ALL_TAB_COMMENTS tc ON tc.OWNER = c.OWNER AND tc.TABLE_NAME = c.TABLE_NAME
                LEFT JOIN ALL_COL_COMMENTS cc ON cc.OWNER = c.OWNER AND cc.TABLE_NAME = c.TABLE_NAME AND cc.COLUMN_NAME = c.COLUMN_NAME
                ORDER BY c.OWNER, c.TABLE_NAME, c.COLUMN_ID
                """;
        List<Col> out = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(DM_URL, DM_USER, DM_PASS);
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Col col = new Col();
                col.owner = nvl(rs.getString("OWNER"));
                if (SYS_OWNERS.contains(col.owner)) continue;
                col.tableName = nvl(rs.getString("TABLE_NAME"));
                col.tableComment = clean(rs.getString("TABLE_COMMENT"));
                col.columnName = nvl(rs.getString("COLUMN_NAME"));
                col.columnComment = clean(rs.getString("COLUMN_COMMENT"));
                col.dataType = nvl(rs.getString("DATA_TYPE"));
                out.add(col);
            }
        }
        return out;
    }

    private static Map<String, FieldRow> readStandardFields() throws SQLException {
        Map<String, FieldRow> out = new LinkedHashMap<>();
        try (Connection c = DriverManager.getConnection(MYSQL_URL, MYSQL_USER, MYSQL_PASS);
             PreparedStatement ps = c.prepareStatement("SELECT field_code, field_name, status FROM om_standard_field");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                FieldRow f = new FieldRow();
                f.code = rs.getString(1);
                f.name = rs.getString(2);
                f.status = rs.getString(3);
                out.put(f.code, f);
            }
        }
        return out;
    }

    private static Map<String, String> readRoots() throws SQLException {
        Map<String, String> out = new LinkedHashMap<>();
        try (Connection c = DriverManager.getConnection(MYSQL_URL, MYSQL_USER, MYSQL_PASS);
             PreparedStatement ps = c.prepareStatement("SELECT root_code, root_name FROM om_term_root");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.put(rs.getString(1), rs.getString(2));
            }
        }
        return out;
    }

    private static void loadSkillRoots(Map<String, String> roots, Path path) {
        if (!Files.exists(path)) return;
        try {
            Pattern p = Pattern.compile("code:\\s*([^,} ]+).*name:\\s*([^,} ]+)");
            for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
                java.util.regex.Matcher m = p.matcher(line);
                if (m.find()) {
                    String code = m.group(1).trim();
                    String name = m.group(2).trim();
                    if (code.matches("[a-z]+") && !name.isBlank()) roots.putIfAbsent(code, name);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static void loadPlatformTerms() {
        Path path = SKILL_REF.resolve("platform-stopwords.yml");
        if (!Files.exists(path)) return;
        try {
            for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
                String s = line.trim();
                if (s.startsWith("- ")) {
                    PLATFORM_WORDS.add(s.substring(2).trim());
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static AuditRow audit(Col col, List<String> rootNames, Map<String, FieldRow> standardFields) {
        AuditRow row = new AuditRow();
        row.col = col;
        if (exclude(col)) {
            row.reason = "技术字段/系统表/日志备份表过滤";
            return row;
        }
        String cn = extractChinese(col.columnComment);
        if (cn.isBlank()) {
            cn = inferFromName(col);
            if (cn.isBlank()) {
                row.reason = "缺少中文注释，字段名/表上下文不足以确认业务含义";
                return row;
            }
            row.reason = "字段名与表上下文弱推断";
        } else {
            row.reason = "字段中文注释";
        }
        row.semanticCn = cn;
        row.platform = isPlatform(cn);
        row.business = !row.platform;
        List<String> terms = split(cn, rootNames);
        if (terms.isEmpty()) {
            row.reason += "；无法按现有词根稳定拆分";
            return row;
        }
        row.fieldName = String.join("", terms);
        row.fieldCode = toPinyinTerms(terms);
        FieldRow f = standardFields.get(row.fieldCode);
        if (f != null) {
            row.exactStandard = true;
            row.standardStatus = f.status;
            row.matchStatus = f.status;
        } else {
            row.matchStatus = "MISSING_STANDARD_FIELD";
            row.reason += "；当前 om_standard_field 无精确标准字段";
        }
        return row;
    }

    private static boolean exclude(Col c) {
        if (BAD_TABLE.matcher(c.tableName).matches()) return true;
        return TECH_COL.matcher(c.columnName).matches();
    }

    private static String inferFromName(Col c) {
        String col = c.columnName.toUpperCase(Locale.ROOT);
        if (EN_DICT.containsKey(col)) {
            String base = EN_DICT.get(col);
            String obj = objectFromContext(c);
            if (!obj.isBlank() && Set.of("名称", "编号", "编码", "日期", "时间", "状态", "类型").contains(base)) return obj + base;
            return base;
        }
        for (Map.Entry<String, String> e : EN_DICT.entrySet()) {
            if (col.endsWith("_" + e.getKey()) || col.endsWith(e.getKey())) {
                String obj = objectFromContext(c);
                if (!obj.isBlank()) return obj + e.getValue();
            }
        }
        return "";
    }

    private static String objectFromContext(Col c) {
        String tc = extractChinese(c.tableComment);
        String[] candidates = {"客户", "项目", "合同", "凭证", "会计", "科目", "资金", "投资", "员工", "人员", "部门", "组织", "供应商", "公司", "机构", "用户", "角色", "岗位", "单据", "业务", "订单"};
        for (String x : candidates) if (tc.contains(x)) return x;
        String t = c.tableName.toUpperCase(Locale.ROOT);
        if (t.contains("KH") || t.contains("CUST")) return "客户";
        if (t.contains("XM") || t.contains("PROJECT")) return "项目";
        if (t.contains("HT") || t.contains("CONTRACT")) return "合同";
        if (t.contains("DEPT") || t.contains("ORG")) return "组织";
        if (t.contains("USER") || t.contains("EMP")) return "用户";
        return "";
    }

    private static List<String> split(String text, List<String> rootNames) {
        String s = text.replaceAll("(信息|数据)$", "");
        List<String> out = new ArrayList<>();
        while (!s.isBlank()) {
            String hit = "";
            for (String root : rootNames) {
                if (!root.isBlank() && s.startsWith(root)) {
                    hit = root;
                    break;
                }
            }
            if (hit.isBlank()) return Collections.emptyList();
            out.add(hit);
            s = s.substring(hit.length());
        }
        return out;
    }

    private static void addFallbackTerms(List<String> terms) {
        String[] more = {
                "日期", "时间", "年", "月", "日", "开始", "结束", "创建", "更新", "修改", "最后",
                "编号", "编码", "代码", "号码", "标识", "标志", "名称", "标题", "类型", "类别", "状态", "等级", "说明", "备注",
                "金额", "数量", "单价", "税额", "比例", "利率", "币种", "币别", "货币", "客户", "项目", "合同", "凭证", "科目",
                "公司", "机构", "组织", "部门", "用户", "人员", "员工", "岗位", "单据", "业务", "主债务", "债务", "本金", "利息",
                "请求", "成功", "失败", "执行", "次数", "率", "行数", "原因", "参数", "结果", "消息", "内容", "耗时", "总数"
        };
        terms.addAll(Arrays.asList(more));
    }

    private static boolean isPlatform(String cn) {
        for (String word : PLATFORM_WORDS) if (cn.contains(word)) return true;
        return false;
    }

    private static String toPinyinTerms(List<String> terms) {
        List<String> codes = new ArrayList<>();
        for (String term : terms) codes.add(toPinyin(term));
        return String.join("_", codes);
    }

    private static String toPinyin(String zh) {
        try {
            HanyuPinyinOutputFormat fmt = new HanyuPinyinOutputFormat();
            fmt.setCaseType(HanyuPinyinCaseType.LOWERCASE);
            fmt.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
            StringBuilder sb = new StringBuilder();
            for (char ch : zh.toCharArray()) {
                if (Character.UnicodeScript.of(ch) == Character.UnicodeScript.HAN) {
                    String[] arr = PinyinHelper.toHanyuPinyinStringArray(ch, fmt);
                    if (arr != null && arr.length > 0) sb.append(arr[0]);
                } else if (Character.isLetterOrDigit(ch)) {
                    sb.append(Character.toLowerCase(ch));
                }
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static String extractChinese(String s) {
        String x = clean(s);
        StringBuilder out = new StringBuilder();
        for (char ch : x.toCharArray()) {
            Character.UnicodeScript script = Character.UnicodeScript.of(ch);
            if (script == Character.UnicodeScript.HAN) out.append(ch);
        }
        return out.toString();
    }

    private static String clean(String s) {
        return nvl(s).replaceAll("[：:;；,，。\\s]+", "");
    }

    private static String nvl(String s) {
        return s == null ? "" : s.trim();
    }

    private static void writeCsv(Path path, List<AuditRow> rows, boolean onlyUncovered) throws Exception {
        try (BufferedWriter w = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            w.write("owner,table_name,table_comment,column_name,column_comment,data_type,semantic_cn,standard_field_code,field_name,match_status,business,platform,reason\n");
            for (AuditRow r : rows) {
                if (onlyUncovered && (!r.business || r.exactStandard)) continue;
                w.write(csv(r.col.owner) + "," + csv(r.col.tableName) + "," + csv(r.col.tableComment) + "," + csv(r.col.columnName) + "," +
                        csv(r.col.columnComment) + "," + csv(r.col.dataType) + "," + csv(r.semanticCn) + "," + csv(r.fieldCode) + "," +
                        csv(r.fieldName) + "," + csv(r.matchStatus) + "," + r.business + "," + r.platform + "," + csv(r.reason) + "\n");
            }
        }
    }

    private static String csv(String s) {
        String x = nvl(s).replace("\"", "\"\"");
        return "\"" + x + "\"";
    }

    private static void printSummary(List<AuditRow> rows) {
        long total = rows.size();
        long business = rows.stream().filter(r -> r.business).count();
        long platform = rows.stream().filter(r -> r.platform).count();
        long noMeaning = rows.stream().filter(r -> !r.business && !r.platform).count();
        long exact = rows.stream().filter(r -> r.business && r.exactStandard).count();
        long active = rows.stream().filter(r -> r.business && "ACTIVE".equals(r.standardStatus)).count();
        long draft = rows.stream().filter(r -> r.business && "DRAFT".equals(r.standardStatus)).count();
        long missing = rows.stream().filter(r -> r.business && !r.exactStandard && !r.fieldCode.isBlank()).count();
        long unsplit = rows.stream().filter(r -> r.business && r.fieldCode.isBlank()).count();
        System.out.println("TOTAL_DM_COLUMNS=" + total);
        System.out.println("BUSINESS_MEANING_FIELDS=" + business);
        System.out.println("PLATFORM_OR_METADATA_FIELDS=" + platform);
        System.out.println("NO_CONFIDENT_MEANING_FIELDS=" + noMeaning);
        System.out.println("EXACT_STANDARD_COVERED=" + exact);
        System.out.println("ACTIVE_STANDARD_COVERED=" + active);
        System.out.println("DRAFT_STANDARD_COVERED=" + draft);
        System.out.println("MISSING_STANDARD_FIELD=" + missing);
        System.out.println("UNSPLIT_OR_INSUFFICIENT_ROOTS=" + unsplit);
        System.out.printf(Locale.ROOT, "COVERAGE_INCLUDING_DRAFT=%.2f%%%n", business == 0 ? 0 : exact * 100.0 / business);
        System.out.printf(Locale.ROOT, "ACTIVE_ONLY_COVERAGE=%.2f%%%n", business == 0 ? 0 : active * 100.0 / business);
        System.out.println("REPORT=tools/review_out/dm_standard_coverage.csv");
        System.out.println("UNCOVERED=tools/review_out/dm_standard_uncovered.csv");
        System.out.println("CLUSTERS=tools/review_out/dm_uncovered_clusters.csv");
    }

    private static void writeClusters(Path path, List<AuditRow> rows) throws Exception {
        Map<String, long[]> counts = new LinkedHashMap<>();
        Map<String, String> sample = new LinkedHashMap<>();
        for (AuditRow r : rows) {
            if (!r.business || r.exactStandard) continue;
            String key = r.fieldCode.isBlank() ? "UNSPLIT:" + r.semanticCn : r.fieldCode;
            counts.computeIfAbsent(key, k -> new long[2])[0]++;
            if (r.fieldCode.isBlank()) counts.get(key)[1]++;
            sample.putIfAbsent(key, r.semanticCn + " | " + r.col.owner + "." + r.col.tableName + "." + r.col.columnName);
        }
        List<Map.Entry<String, long[]>> entries = new ArrayList<>(counts.entrySet());
        entries.sort((a, b) -> Long.compare(b.getValue()[0], a.getValue()[0]));
        try (BufferedWriter w = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            w.write("cluster_key,count,unsplit_count,sample\n");
            for (Map.Entry<String, long[]> e : entries) {
                w.write(csv(e.getKey()) + "," + e.getValue()[0] + "," + e.getValue()[1] + "," + csv(sample.get(e.getKey())) + "\n");
            }
        }
    }
}
