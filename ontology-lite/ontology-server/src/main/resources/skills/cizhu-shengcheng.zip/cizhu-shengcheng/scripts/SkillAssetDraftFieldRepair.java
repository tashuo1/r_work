import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

public class SkillAssetDraftFieldRepair {

    private static String getenv(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }
    private static final String MYSQL_URL = getenv("CIZHU_MYSQL_URL", "jdbc:mysql://127.0.0.1:3306/ontology_meta?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&rewriteBatchedStatements=true");
    private static final String MYSQL_USER = getenv("CIZHU_MYSQL_USER", "root");
    private static final String MYSQL_PASS = getenv("CIZHU_MYSQL_PASSWORD", "");
    private static final long TENANT_ID = 1L;
    private static final Path SKILL_REF = Path.of(getenv("CIZHU_SKILL_HOME", "."), "references");
    private static final Path CLUSTERS = Path.of("tools", "review_out", "dm_uncovered_clusters.csv");

    static class Root {
        String code, name, domain, status;
        Root(String c, String n, String d, String s) {
            code = c; name = n; domain = d; status = s;
        }
    }

    static class Cluster {
        String code, sample;
        int count;
    }

    public static void main(String[] args) throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Map<String, Root> skillRoots = loadSkillRoots();
        List<Cluster> clusters = loadClusters();
        try (Connection c = DriverManager.getConnection(MYSQL_URL, MYSQL_USER, MYSQL_PASS)) {
            c.setAutoCommit(false);
            Map<String, Root> remoteRoots = loadRemoteRoots(c);
            Map<String, Long> rootIds = loadIds(c, "om_term_root", "root_code");
            Map<String, Long> fieldIds = loadIds(c, "om_standard_field", "field_code");
            int rootInserted = 0, fieldInserted = 0, mapInserted = 0, skipped = 0;

            for (Cluster cluster : clusters) {
                if (cluster.code.startsWith("UNSPLIT:") || !cluster.code.matches("[a-z]+(_[a-z]+)*")) {
                    skipped++;
                    continue;
                }
                String[] segments = cluster.code.split("_");
                List<Root> roots = new ArrayList<>();
                boolean usable = true;
                for (String seg : segments) {
                    Root root = remoteRoots.get(seg);
                    if (root == null) root = skillRoots.get(seg);
                    if (root == null) {
                        usable = false;
                        break;
                    }
                    roots.add(root);
                }
                if (!usable || roots.isEmpty()) {
                    skipped++;
                    continue;
                }
                for (Root root : roots) {
                    if (!rootIds.containsKey(root.code)) {
                        long id = insertDraftRoot(c, root);
                        rootIds.put(root.code, id);
                        remoteRoots.put(root.code, new Root(root.code, root.name, root.domain, "DRAFT"));
                        rootInserted++;
                    }
                }
                Long fieldId = fieldIds.get(cluster.code);
                if (fieldId == null) {
                    fieldId = insertDraftField(c, cluster, roots);
                    fieldIds.put(cluster.code, fieldId);
                    fieldInserted++;
                }
                for (Root root : roots) {
                    Long rootId = rootIds.get(root.code);
                    if (rootId != null && insertInactiveMap(c, rootId, fieldId)) {
                        mapInserted++;
                    }
                }
            }
            c.commit();
            System.out.println("CLUSTERS_READ=" + clusters.size());
            System.out.println("DRAFT_ROOTS_INSERTED=" + rootInserted);
            System.out.println("DRAFT_FIELDS_INSERTED=" + fieldInserted);
            System.out.println("INACTIVE_MAPS_INSERTED=" + mapInserted);
            System.out.println("SKIPPED=" + skipped);
        }
    }

    private static Map<String, Root> loadSkillRoots() throws Exception {
        Map<String, Root> roots = new LinkedHashMap<>();
        loadSkillRootsFile(roots, SKILL_REF.resolve("common-roots.yml"), "common");
        loadSkillRootsFile(roots, SKILL_REF.resolve("domain-roots-finance.yml"), "finance");
        loadSkillRootsFile(roots, SKILL_REF.resolve("domain-roots-hr.yml"), "hr");
        loadSkillRootsFile(roots, SKILL_REF.resolve("domain-roots-investment.yml"), "investment");
        return roots;
    }

    private static void loadSkillRootsFile(Map<String, Root> roots, Path path, String fallbackDomain) throws Exception {
        if (!Files.exists(path)) return;
        Pattern codeP = Pattern.compile("code:\\s*([^,} ]+)");
        Pattern nameP = Pattern.compile("name:\\s*([^,} ]+)");
        Pattern domainP = Pattern.compile("domain:\\s*([^,} ]+)");
        for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
            var codeM = codeP.matcher(line);
            var nameM = nameP.matcher(line);
            if (!codeM.find() || !nameM.find()) continue;
            String code = codeM.group(1).trim();
            String name = nameM.group(1).trim();
            if (!code.matches("[a-z]+") || name.isBlank()) continue;
            var domainM = domainP.matcher(line);
            String domain = domainM.find() ? domainM.group(1).trim() : fallbackDomain;
            roots.putIfAbsent(code, new Root(code, name, domain, "DRAFT"));
        }
    }

    private static List<Cluster> loadClusters() throws Exception {
        List<Cluster> out = new ArrayList<>();
        if (!Files.exists(CLUSTERS)) throw new IllegalStateException("missing cluster report: " + CLUSTERS);
        try (BufferedReader r = Files.newBufferedReader(CLUSTERS, StandardCharsets.UTF_8)) {
            String header = r.readLine();
            String line;
            while ((line = r.readLine()) != null) {
                List<String> cols = parseCsv(line);
                if (cols.size() < 4) continue;
                Cluster c = new Cluster();
                c.code = cols.get(0);
                c.count = Integer.parseInt(cols.get(1));
                c.sample = cols.get(3);
                out.add(c);
            }
        }
        out.sort((a, b) -> Integer.compare(b.count, a.count));
        return out;
    }

    private static Map<String, Root> loadRemoteRoots(Connection c) throws SQLException {
        Map<String, Root> out = new LinkedHashMap<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT root_code, root_name, domain_name, status FROM om_term_root WHERE tenant_id=?")) {
            ps.setLong(1, TENANT_ID);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.put(rs.getString(1), new Root(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
                }
            }
        }
        return out;
    }

    private static Map<String, Long> loadIds(Connection c, String table, String codeCol) throws SQLException {
        Map<String, Long> out = new LinkedHashMap<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT id," + codeCol + " FROM " + table + " WHERE tenant_id=?")) {
            ps.setLong(1, TENANT_ID);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.put(rs.getString(2), rs.getLong(1));
            }
        }
        return out;
    }

    private static long insertDraftRoot(Connection c, Root root) throws SQLException {
        String sql = "INSERT INTO om_term_root (tenant_id, root_code, root_name, biz_definition, domain_name, status) VALUES (?,?,?,?,?,'DRAFT')";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, TENANT_ID);
            ps.setString(2, root.code);
            ps.setString(3, root.name);
            ps.setString(4, "待确认词根：" + root.name + "；来源：cizhu-shengcheng skill 资产与达梦未覆盖聚类；状态：待人工确认");
            ps.setString(5, root.domain);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getLong(1);
            }
        }
        throw new SQLException("no generated key for root " + root.code);
    }

    private static long insertDraftField(Connection c, Cluster cluster, List<Root> roots) throws SQLException {
        String name = roots.stream().map(r -> r.name).reduce("", String::concat);
        String definition = "口径：" + name + "；来源：达梦未覆盖语义聚类；生成方式：SKILL_CLUSTER_DRAFT；置信状态：待确认；覆盖物理字段数：" + cluster.count + "；样例：" + trim(cluster.sample, 120);
        String sql = "INSERT INTO om_standard_field (tenant_id, field_code, field_name, field_type, biz_definition, combo_key, status) VALUES (?,?,?,?,?,?,'DRAFT')";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, TENANT_ID);
            ps.setString(2, cluster.code);
            ps.setString(3, name);
            ps.setString(4, "STRING");
            ps.setString(5, trim(definition, 500));
            ps.setString(6, "draft_cluster_" + cluster.code);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getLong(1);
            }
        }
        throw new SQLException("no generated key for field " + cluster.code);
    }

    private static boolean insertInactiveMap(Connection c, long rootId, long fieldId) throws SQLException {
        String sql = "INSERT IGNORE INTO om_root_field_map (tenant_id, root_id, standard_field_id, relation_type, weight_score, status) VALUES (?,?,?,'SYNONYM',1.00,'INACTIVE')";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, TENANT_ID);
            ps.setLong(2, rootId);
            ps.setLong(3, fieldId);
            return ps.executeUpdate() > 0;
        }
    }

    private static List<String> parseCsv(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean quote = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (quote && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    sb.append('"');
                    i++;
                } else {
                    quote = !quote;
                }
            } else if (ch == ',' && !quote) {
                out.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(ch);
            }
        }
        out.add(sb.toString());
        return out;
    }

    private static String trim(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 3) + "...";
    }
}
