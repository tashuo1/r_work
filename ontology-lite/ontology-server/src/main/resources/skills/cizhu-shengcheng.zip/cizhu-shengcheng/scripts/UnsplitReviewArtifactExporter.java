import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class UnsplitReviewArtifactExporter {

    private static String getenv(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }
    private static final Path CLUSTERS = Path.of("tools", "review_out", "dm_uncovered_clusters.csv");
    private static final Path OUT = Path.of("tools", "review_out", "unsplit_review_candidates.csv");

    public static void main(String[] args) throws Exception {
        Files.createDirectories(OUT.getParent());
        int written = 0;
        try (BufferedReader r = Files.newBufferedReader(CLUSTERS, StandardCharsets.UTF_8);
             BufferedWriter w = Files.newBufferedWriter(OUT, StandardCharsets.UTF_8)) {
            r.readLine();
            w.write("semantic_cn,count,category,recommended_action,llm_task,sample\n");
            String line;
            while ((line = r.readLine()) != null) {
                List<String> cols = parseCsv(line);
                if (cols.size() < 4 || !cols.get(0).startsWith("UNSPLIT:")) continue;
                String semantic = cols.get(0).substring("UNSPLIT:".length());
                int count = Integer.parseInt(cols.get(1));
                String sample = cols.get(3);
                String category = category(semantic);
                String action = switch (category) {
                    case "TECH_PLATFORM" -> "REJECT_PLATFORM_OR_TECHNICAL";
                    case "ENUM_STATUS" -> "REVIEW_ENUM_FIELD";
                    case "FINANCE_REPORT_METRIC" -> "LLM_SPLIT_TO_REVIEW_ARTIFACT";
                    default -> "NEEDS_BUSINESS_OWNER";
                };
                String task = "按词根规范拆成原子中文词；禁止整句词根；禁止固定字数切分；输出root_names, field_code, confidence, reject_reason";
                w.write(csv(semantic) + "," + count + "," + category + "," + action + "," + csv(task) + "," + csv(sample) + "\n");
                written++;
            }
        }
        System.out.println("REVIEW_CANDIDATES_WRITTEN=" + written);
        System.out.println("OUT=" + OUT);
    }

    private static String category(String s) {
        if (s.matches(".*(交换器|客户端|事务|数据流|主表|版本号|校验码|删除关联|短文本|整数|操作人|创建人|最后操作人).*")) return "TECH_PLATFORM";
        if (s.matches(".*(是否|状态|标识).*(成功|失败|待处理|完成|启用|验真|入账|上报).*")) return "ENUM_STATUS";
        if (s.matches(".*(金额|余额|资本|股东|资产|负债|权益|收入|费用|利润|金融|出资|公积|收益|储备|准备|应收|存货|凭证|会计|税率).*")) return "FINANCE_REPORT_METRIC";
        return "BUSINESS_AMBIGUOUS";
    }

    private static List<String> parseCsv(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean quote = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (quote && i + 1 < line.length() && line.charAt(i + 1) == '"') { sb.append('"'); i++; }
                else quote = !quote;
            } else if (ch == ',' && !quote) {
                out.add(sb.toString()); sb.setLength(0);
            } else sb.append(ch);
        }
        out.add(sb.toString());
        return out;
    }

    private static String csv(String s) {
        return "\"" + (s == null ? "" : s.replace("\"", "\"\"")) + "\"";
    }
}
