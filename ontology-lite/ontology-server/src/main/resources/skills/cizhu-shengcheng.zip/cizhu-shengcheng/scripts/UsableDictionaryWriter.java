import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;

import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

public class UsableDictionaryWriter {

    private static String getenv(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }
    private static final String DM_URL = getenv("CIZHU_DM_URL", "jdbc:dm://127.0.0.1:5236");
    private static final String DM_USER = getenv("CIZHU_DM_USER", "SYSDBA");
    private static final String DM_PASS = getenv("CIZHU_DM_PASSWORD", "");
    private static final String MYSQL_URL = getenv("CIZHU_MYSQL_URL", "jdbc:mysql://127.0.0.1:3306/ontology_meta?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&rewriteBatchedStatements=true");
    private static final String MYSQL_USER = getenv("CIZHU_MYSQL_USER", "root");
    private static final String MYSQL_PASS = getenv("CIZHU_MYSQL_PASSWORD", "");
    private static final long TENANT_ID = 1L;

    private static final Set<String> SYS_OWNERS = Set.of("SYS", "SYSTEM", "SYSAUDITOR", "SYSSSO", "SYSDBA", "CTISYS", "DMHS", "DMSYS", "SYSJOB");
    private static final Pattern TECH_COL = Pattern.compile("(?i)^(id|row_id|uuid|guid|del_flag|delete_flag|is_deleted|create_by|created_by|update_by|updated_by|version|tenant_id|trace_id|request_id|sort|ts|dr)$");
    private static final Pattern BAD_TABLE = Pattern.compile("(?i).*(temp|tmp|bak|backup|log|audit|cache|snapshot).*");
    private static final Set<String> BAD_COMMENT = Set.of(
            "表定义", "字段定义", "关联模板", "表标识", "表标题", "表类型", "目标表", "源表",
            "目标表定义", "源表定义", "定义数据", "适应条件", "启用标识", "生单时机",
            "配置节点", "审批节点", "表单分类", "目标表名称", "源表名称", "映射模板",
            "配置", "设置", "模板", "按钮控制"
    );
    private static final Map<String, String> EN_DICT = new HashMap<>();
    private static final List<String> TERMS = new ArrayList<>();
    private static final LinkedHashMap<String, String> ATTRIBUTE_SUFFIXES = new LinkedHashMap<>();

    static {
        String[][] en = {
                {"NAME", "名称"}, {"MC", "名称"}, {"TITLE", "标题"}, {"CODE", "编码"}, {"BM", "编码"}, {"NO", "编号"}, {"BH", "编号"},
                {"DATE", "日期"}, {"RQ", "日期"}, {"TIME", "时间"}, {"CREATETIME", "创建时间"}, {"CREATE_TIME", "创建时间"},
                {"UPDATETIME", "更新时间"}, {"UPDATE_TIME", "更新时间"}, {"AMOUNT", "金额"}, {"AMT", "金额"}, {"JE", "金额"},
                {"MONEY", "金额"}, {"STATUS", "状态"}, {"STATE", "状态"}, {"TYPE", "类型"}, {"FLAG", "标志"},
                {"PHONE", "电话"}, {"MOBILE", "手机"}, {"EMAIL", "邮箱"}, {"ADDRESS", "地址"}, {"ADDR", "地址"},
                {"REMARK", "备注"}, {"BZ", "备注"}
        };
        for (String[] e : en) EN_DICT.put(e[0], e[1]);
        String[][] suffixes = {
                {"时间", "shijian"}, {"日期", "riqi"}, {"名称", "mingcheng"}, {"编号", "bianhao"},
                {"编码", "bianma"}, {"类型", "leixing"}, {"状态", "zhuangtai"}, {"金额", "jine"},
                {"号码", "haoma"}, {"代码", "daima"}, {"标志", "biaozhi"}, {"说明", "shuoming"}, {"地址", "dizhi"},
                {"标识", "biaoshi"}, {"标题", "biaoti"}, {"定义", "dingyi"}, {"模板", "moban"},
                {"数据", "shuju"}, {"条件", "tiaojian"}, {"依据", "yiju"}, {"时机", "shiji"},
                {"用户", "yonghu"}, {"值", "zhi"}, {"次数", "cishu"}, {"率", "lv"},
                {"行数", "xingshu"}, {"原因", "yuanyin"}, {"参数", "canshu"}, {"结果", "jieguo"},
                {"消息", "xiaoxi"}, {"内容", "neirong"}, {"耗时", "haoshi"}, {"总数", "zongshu"},
                {"描述", "miaoshu"}, {"方案", "fangan"}, {"单位", "danwei"}, {"规则", "guize"},
                {"对象", "duixiang"}, {"主键", "zhujian"}, {"字段", "ziduan"},
                {"映射", "yingshe"}, {"注释", "zhushi"}, {"队列", "duilie"}, {"流程", "liucheng"},
                {"节点", "jiedian"}, {"权限", "quanxian"}, {"缓存", "huancun"},
                {"图标", "tubiao"}, {"实例", "shili"},
                {"服务", "fuwu"}, {"排序", "paixu"}, {"路径", "lujing"}, {"顺序", "shunxu"}, {"序号", "xuhao"}, {"范围", "fanwei"},
                {"方式", "fangshi"}, {"人员", "renyuan"}, {"记录数", "jilushu"}, {"字节", "zijie"},
                {"长度", "zhangdu"}, {"大小", "daxiao"}, {"收入", "shouru"}, {"支出", "zhichu"},
                {"利润", "lirun"}, {"余额", "yue"}, {"总额", "zonge"}
        };
        for (String[] s : suffixes) ATTRIBUTE_SUFFIXES.put(s[0], s[1]);
        String[] terms = {
                "统一社会信用", "身份证", "银行卡", "手机号", "电话号码", "电子邮件",
                "凭证", "会计", "科目", "成本", "中心", "客户", "供应商", "往来", "公司", "法人", "主体",
                "机构", "组织", "部门", "岗位", "用户", "员工", "人员", "姓名", "性别", "出生", "入职", "离职",
                "项目", "投资", "计划", "资金", "投放", "合同", "风险", "事件", "最后", "指标", "薪酬", "工资",
                "请求", "成功", "失败", "执行", "重试", "触发", "使用", "变更", "错误", "打印", "出现",
                "描述", "方案", "单位", "规则", "对象", "主键", "字段", "映射", "注释",
                "队列", "流程", "节点", "权限", "缓存", "图标", "实例", "服务", "排序",
                "路径", "顺序", "序号", "范围", "方式",
                "记录数", "字节", "长度", "大小", "收入", "支出", "利润", "余额", "总额",
                "名称", "标题", "编号", "编码", "代码", "号码", "日期", "时间", "金额", "余额", "数量", "单价",
                "状态", "类型", "类别", "标志", "标识", "备注", "说明", "地址", "电话", "手机", "邮箱", "证件",
                "创建", "更新", "开始", "结束", "生效", "失效", "审核", "确认", "发生", "付款", "收款",
                "业务", "来源", "目标", "源", "数据", "分组", "条件", "规则", "映射", "用途", "口径",
                "年度", "季度", "月份", "年", "月", "日", "币别", "币种", "税额", "比例", "利率"
        };
        TERMS.addAll(Arrays.asList(terms));
        TERMS.add("监控");
        TERMS.sort((a, b) -> Integer.compare(b.length(), a.length()));
    }

    static class Col { String owner, tableName, tableComment, columnName, columnComment, dataType; }
    static class RootDef {
        String code, name, domain, status;
        RootDef(String c, String n, String d) { this(c, n, d, "ACTIVE"); }
        RootDef(String c, String n, String d, String s) { code=c; name=n; domain=d; status=s; }
    }
    static class FieldDef {
        String code, name, type, definition, status, level; List<String> roots; int physicalCount = 0;
        List<Col> examples = new ArrayList<>();
        FieldDef(String c, String n, String t, String d, List<String> r, String s, String l) {
            code=c; name=n; type=t; definition=d; roots=r; status=s; level=l;
        }
    }
    static class Inference {
        String chinese, status, level, reason;
        Inference(String c, String s, String l, String r) { chinese=c; status=s; level=l; reason=r; }
    }

    private static final String[][] BASE_ROOTS = {
            {"riqi","日期","common"},{"shijian","时间","common"},{"nian","年","common"},{"yue","月","common"},{"ri","日","common"},
            {"kaishi","开始","common"},{"jieshu","结束","common"},{"chuangjian","创建","common"},{"gengxin","更新","common"},{"xiugai","修改","common"},
            {"bianhao","编号","common"},{"bianma","编码","common"},{"daima","代码","common"},{"haoma","号码","common"},{"biaoshi","标识","common"},{"biaozhi","标志","common"},
            {"mingcheng","名称","common"},{"biaoti","标题","common"},{"leixing","类型","common"},{"leibie","类别","common"},{"zhuangtai","状态","common"},{"dengji","等级","common"},{"shuoming","说明","common"},{"beizhu","备注","common"},
            {"jine","金额","common"},{"shuliang","数量","common"},{"danjia","单价","common"},{"shuier","税额","common"},{"bili","比例","common"},{"lilv","利率","common"},
            {"bizhong","币种","common"},{"bibie","币别","common"},{"huobi","货币","common"},
            {"shouji","手机","common"},{"dianhua","电话","common"},{"youxiang","邮箱","common"},{"dizhi","地址","common"},
            {"yonghu","用户","common"},{"renyuan","人员","common"},{"yuangong","员工","hr"},{"zuzhi","组织","common"},{"bumen","部门","common"},{"gangwei","岗位","hr"},
            {"caozuo","操作","common"},{"shenhe","审核","common"},{"queren","确认","common"},{"shengxiao","生效","common"},{"shixiao","失效","common"},
            {"zhi","值","common"},{"zhibiao","指标","common"},{"jiankong","监控","common"},{"zuihou","最后","common"},
            {"cishu","次数","common"},{"lv","率","common"},{"xingshu","行数","common"},{"yuanyin","原因","common"},
            {"canshu","参数","common"},{"jieguo","结果","common"},{"xiaoxi","消息","common"},{"neirong","内容","common"},
            {"haoshi","耗时","common"},{"zongshu","总数","common"},{"qingqiu","请求","common"},{"chenggong","成功","common"},
            {"shibai","失败","common"},{"zhixing","执行","common"},{"zhongshi","重试","common"},{"chufa","触发","common"},
            {"shiyong","使用","common"},{"biangeng","变更","common"},{"cuowu","错误","common"},{"dayin","打印","common"},
            {"chuxian","出现","common"},{"miaoshu","描述","common"},{"fangan","方案","common"},{"danwei","单位","common"},
            {"guize","规则","common"},{"duixiang","对象","common"},{"zhujian","主键","common"},
            {"ziduan","字段","common"},{"yingshe","映射","common"},{"zhushi","注释","common"},{"duilie","队列","common"},
            {"liucheng","流程","common"},{"jiedian","节点","common"},{"quanxian","权限","common"},{"huancun","缓存","common"},
            {"tubiao","图标","common"},{"shili","实例","common"},
            {"fuwu","服务","common"},{"paixu","排序","common"},{"lujing","路径","common"},{"shunxu","顺序","common"},{"xuhao","序号","common"},
            {"fanwei","范围","common"},{"fangshi","方式","common"},{"jilushu","记录数","common"},{"zijie","字节","common"},
            {"zhangdu","长度","common"},{"daxiao","大小","common"},{"shouru","收入","common"},{"zhichu","支出","common"},
            {"lirun","利润","common"},{"zonge","总额","common"}
    };

    public static void main(String[] args) throws Exception {
        Class.forName("dm.jdbc.driver.DmDriver");
        Class.forName("com.mysql.cj.jdbc.Driver");
        List<Col> cols = readColumns();
        Map<String, RootDef> roots = new LinkedHashMap<>();
        seedBaseRoots(roots);
        Map<String, FieldDef> fields = new LinkedHashMap<>();
        int effective = 0, mapped = 0, skipped = 0;
        for (Col col : cols) {
            if (exclude(col)) { skipped++; continue; }
            effective++;
            Inference inf = inferChinese(col);
            if (inf.chinese.isBlank()) { skipped++; continue; }
            boolean platformCandidate = isPlatformMetadataPhrase(inf.chinese);
            List<String> terms = splitTerms(inf.chinese);
            if (terms.isEmpty()) {
                terms = draftTerms(inf.chinese);
                if (terms.isEmpty()) { skipped++; continue; }
                inf = new Inference(inf.chinese, "DRAFT", "CANDIDATE_LOW", inf.reason + "；无法完全命中已知词根，生成待确认原子词根");
            }
            if (platformCandidate) {
                inf = new Inference(inf.chinese, "DRAFT", "PENDING_REVIEW", inf.reason + "；平台/技术语义，待确认归属域");
            }
            List<String> rootCodes = new ArrayList<>();
            for (String t : terms) {
                String code = toPinyin(t);
                if (code.isBlank() || code.length() > 64) continue;
                rootCodes.add(code);
                upsertRoot(roots, code, t, guessDomain(col.owner, col.tableComment, inf.chinese), inf.status);
            }
            if (rootCodes.isEmpty()) { skipped++; continue; }
            if (hasHomophoneConflict(terms, rootCodes)) {
                inf = new Inference(inf.chinese, "DRAFT", "PENDING_REVIEW", inf.reason + "；存在同音冲突，待人工确认");
            }
            String fieldCode = String.join("_", rootCodes);
            if (fieldCode.length() > 128) { skipped++; continue; }
            String fieldName = String.join("", terms);
            String def = "口径：" + fieldName + "；来源示例：" + col.owner + "." + col.tableName + "." + col.columnName
                    + "；生成方式：" + inf.level + "；置信状态：" + ("ACTIVE".equals(inf.status) ? "已确认" : "待确认")
                    + "；依据：" + inf.reason;
            FieldDef existing = fields.get(fieldCode);
            if (existing == null) {
                fields.put(fieldCode, new FieldDef(fieldCode, fieldName, normalizeType(col.dataType), def, rootCodes, inf.status, inf.level));
            } else if ("ACTIVE".equals(inf.status) && !"ACTIVE".equals(existing.status)) {
                existing.status = "ACTIVE";
                existing.level = inf.level;
                existing.definition = def;
            }
            FieldDef target = fields.get(fieldCode);
            target.physicalCount++;
            if (target.examples.size() < 3) target.examples.add(col);
            mapped++;
        }
        enrichDefinitions(cols, fields);
        writeMysql(roots, fields);
        System.out.println("DM_COLUMNS=" + cols.size());
        System.out.println("EFFECTIVE_FIELDS=" + effective);
        System.out.println("MAPPED_PHYSICAL_FIELDS=" + mapped);
        System.out.println("SKIPPED=" + skipped);
        System.out.println("ROOTS_WRITTEN=" + roots.size());
        System.out.println("FIELDS_WRITTEN=" + fields.size());
        System.out.printf(Locale.ROOT, "MAPPING_COVERAGE=%.2f%%%n", effective == 0 ? 0 : mapped * 100.0 / effective);
    }

    private static List<Col> readColumns() throws SQLException {
        String sql = """
                SELECT c.OWNER, c.TABLE_NAME, tc.COMMENTS AS TABLE_COMMENT,
                       c.COLUMN_NAME, cc.COMMENTS AS COLUMN_COMMENT, c.DATA_TYPE
                FROM ALL_TAB_COLUMNS c
                LEFT JOIN ALL_TAB_COMMENTS tc ON tc.OWNER = c.OWNER AND tc.TABLE_NAME = c.TABLE_NAME
                LEFT JOIN ALL_COL_COMMENTS cc ON cc.OWNER = c.OWNER AND cc.TABLE_NAME = c.TABLE_NAME AND cc.COLUMN_NAME = c.COLUMN_NAME
                ORDER BY c.OWNER, c.TABLE_NAME, c.COLUMN_ID
                """;
        List<Col> out = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(DM_URL, DM_USER, DM_PASS);
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Col col = new Col();
                col.owner = rs.getString("OWNER");
                if (SYS_OWNERS.contains(col.owner)) continue;
                col.tableName = rs.getString("TABLE_NAME");
                col.tableComment = clean(rs.getString("TABLE_COMMENT"));
                col.columnName = rs.getString("COLUMN_NAME");
                col.columnComment = clean(rs.getString("COLUMN_COMMENT"));
                col.dataType = rs.getString("DATA_TYPE");
                out.add(col);
            }
        }
        return out;
    }

    private static boolean exclude(Col c) {
        if (BAD_TABLE.matcher(nvl(c.tableName)).matches()) return true;
        if (TECH_COL.matcher(nvl(c.columnName)).matches()) return true;
        String cc = nvl(c.columnComment);
        for (String b : BAD_COMMENT) if (cc.contains(b)) return true;
        return false;
    }

    private static Inference inferChinese(Col c) {
        String cc = extractChinese(c.columnComment);
        if (!cc.isBlank()) return new Inference(cc, "ACTIVE", "L1", "字段中文注释明确");
        String col = nvl(c.columnName).toUpperCase(Locale.ROOT);
        if (EN_DICT.containsKey(col)) {
            String prefix = objectFromContext(c);
            String base = EN_DICT.get(col);
            if (!prefix.isBlank() && Set.of("名称","编号","编码","日期","时间","状态","类型").contains(base)) {
                return new Inference(prefix + base, "DRAFT", "L2", "字段名词典命中 + 表上下文推断，待确认");
            }
            return new Inference(base, "DRAFT", "L3", "仅字段名词典命中，缺少对象上下文，待确认");
        }
        return new Inference("", "REJECTED", "L4", "无可用中文语义证据");
    }

    private static String objectFromContext(Col c) {
        String tc = extractChinese(c.tableComment);
        if (tc.length() >= 2) {
            for (String term : TERMS) {
                if (tc.contains(term) && !Set.of("数据","信息","表","明细").contains(term)) return term;
            }
        }
        String t = nvl(c.tableName).toUpperCase(Locale.ROOT);
        if (t.contains("CUSTOMER") || t.contains("CUST") || t.contains("KH")) return "客户";
        if (t.contains("PROJECT") || t.contains("XM")) return "项目";
        if (t.contains("EMP") || t.contains("USER")) return "用户";
        if (t.contains("ORG") || t.contains("DEPT")) return "组织";
        if (t.contains("VOUCHER") || t.contains("PZ")) return "凭证";
        if (t.contains("CONTRACT")) return "合同";
        return "";
    }

    private static List<String> splitTerms(String zh) {
        String s = zh.replaceAll("(字段|信息|数据)$", "");
        List<String> bySuffix = splitByAttributeSuffix(s);
        if (!bySuffix.isEmpty()) return bySuffix;
        List<String> out = new ArrayList<>();
        while (!s.isBlank()) {
            String hit = null;
            for (String term : TERMS) {
                if (s.startsWith(term)) { hit = term; break; }
            }
            if (hit != null) {
                out.add(normalizeTerm(hit));
                s = s.substring(hit.length());
            } else {
                return List.of();
            }
        }
        return out;
    }

    private static List<String> draftTerms(String zh) {
        String s = zh.replaceAll("(字段|信息|数据)$", "");
        if (s.isBlank() || s.length() > 12) return List.of();
        List<String> byKnownTerms = splitPrefix(s);
        if (byKnownTerms.size() >= 2) return byKnownTerms;
        List<String> bySuffix = draftBySuffix(s);
        if (!bySuffix.isEmpty()) return bySuffix;
        return List.of();
    }

    private static List<String> draftBySuffix(String s) {
        for (String suffix : ATTRIBUTE_SUFFIXES.keySet()) {
            if (s.endsWith(suffix) && s.length() > suffix.length()) {
                String prefix = s.substring(0, s.length() - suffix.length());
                if (prefix.isBlank() || prefix.length() > 8) return List.of();
                List<String> prefixTerms = splitPrefix(prefix);
                if (prefixTerms.isEmpty() && isReviewableAtomicTerm(prefix)) {
                    prefixTerms = List.of(prefix);
                }
                if (prefixTerms.isEmpty()) return List.of();
                List<String> out = new ArrayList<>(prefixTerms);
                out.add(suffix);
                return out;
            }
        }
        return List.of();
    }

    private static boolean isReviewableAtomicTerm(String s) {
        if (s.length() < 2 || s.length() > 4) return false;
        if (Set.of("字段", "表名", "表结构", "索引", "配置", "模板", "日志", "审计").contains(s)) return false;
        for (String suffix : ATTRIBUTE_SUFFIXES.keySet()) {
            if (s.endsWith(suffix) && s.length() > suffix.length()) return false;
        }
        return true;
    }

    private static List<String> splitByAttributeSuffix(String s) {
        for (String suffix : ATTRIBUTE_SUFFIXES.keySet()) {
            if (s.endsWith(suffix) && s.length() > suffix.length()) {
                String prefix = s.substring(0, s.length() - suffix.length());
                if (prefix.isBlank()) return List.of();
                List<String> prefixTerms = splitPrefix(prefix);
                if (prefixTerms.isEmpty()) return List.of();
                List<String> out = new ArrayList<>(prefixTerms);
                out.add(suffix);
                return out;
            }
        }
        return List.of();
    }

    private static List<String> splitPrefix(String s) {
        List<String> nested = splitByAttributeSuffix(s);
        if (!nested.isEmpty()) return nested;
        List<String> out = new ArrayList<>();
        String rest = s;
        while (!rest.isBlank()) {
            String hit = null;
            for (String term : TERMS) {
                if (rest.startsWith(term) && !ATTRIBUTE_SUFFIXES.containsKey(rest)) { hit = term; break; }
            }
            if (hit != null) {
                out.add(normalizeTerm(hit));
                rest = rest.substring(hit.length());
            } else {
                return List.of();
            }
        }
        return out;
    }

    private static String normalizeTerm(String t) {
        return switch (t) {
            case "手机号" -> "手机";
            case "电话号码" -> "电话";
            case "年度" -> "年";
            case "季度" -> "季";
            case "月份" -> "月";
            default -> t;
        };
    }

    private static void writeMysql(Map<String, RootDef> roots, Map<String, FieldDef> fields) throws SQLException {
        try (Connection c = DriverManager.getConnection(MYSQL_URL, MYSQL_USER, MYSQL_PASS)) {
            c.setAutoCommit(false);
            clearDictionaryTables(c);
            try (PreparedStatement ps = c.prepareStatement("INSERT IGNORE INTO om_tenant (id, tenant_code, tenant_name, status) VALUES (1,'default','默认租户','ACTIVE')")) { ps.executeUpdate(); }
            try (PreparedStatement ps = c.prepareStatement("INSERT IGNORE INTO om_term_root (tenant_id, root_code, root_name, biz_definition, domain_name, status) VALUES (?,?,?,?,?,?)")) {
                int i = 0;
                for (RootDef r : roots.values()) {
                    ps.setLong(1, TENANT_ID); ps.setString(2, r.code); ps.setString(3, r.name);
                    ps.setString(4, ("ACTIVE".equals(r.status) ? "规范词根：" : "待确认词根：") + r.name + "；来源：本地达梦字段语义聚类");
                    ps.setString(5, r.domain); ps.setString(6, r.status); ps.addBatch();
                    if (++i % 1000 == 0) ps.executeBatch();
                }
                ps.executeBatch();
            }
            try (PreparedStatement ps = c.prepareStatement("INSERT IGNORE INTO om_standard_field (tenant_id, field_code, field_name, field_type, biz_definition, combo_key, status) VALUES (?,?,?,?,?,?,?)")) {
                int i = 0, seq = 1;
                for (FieldDef f : fields.values()) {
                    ps.setLong(1, TENANT_ID); ps.setString(2, f.code); ps.setString(3, f.name); ps.setString(4, f.type);
                    ps.setString(5, f.definition + "；覆盖物理字段数：" + f.physicalCount);
                    ps.setString(6, String.format("%05d_%s", seq++, f.code)); ps.setString(7, f.status); ps.addBatch();
                    if (++i % 1000 == 0) ps.executeBatch();
                }
                ps.executeBatch();
            }
            Map<String, Long> rootIds = loadIds(c, "om_term_root", "root_code");
            Map<String, Long> fieldIds = loadIds(c, "om_standard_field", "field_code");
            try (PreparedStatement ps = c.prepareStatement("INSERT IGNORE INTO om_root_field_map (tenant_id, root_id, standard_field_id, relation_type, weight_score, status) VALUES (?,?,?,'SYNONYM',1.00,?)")) {
                int i = 0;
                for (FieldDef f : fields.values()) {
                    Long fid = fieldIds.get(f.code);
                    if (fid == null) continue;
                    for (String root : new LinkedHashSet<>(f.roots)) {
                        Long rid = rootIds.get(root);
                        if (rid == null) continue;
                        ps.setLong(1, TENANT_ID); ps.setLong(2, rid); ps.setLong(3, fid);
                        ps.setString(4, "ACTIVE".equals(f.status) ? "ACTIVE" : "INACTIVE");
                        ps.addBatch();
                        if (++i % 2000 == 0) ps.executeBatch();
                    }
                }
                ps.executeBatch();
            }
            writeSynonyms(c, rootIds);
            c.commit();
        }
    }

    private static void enrichDefinitions(List<Col> cols, Map<String, FieldDef> fields) {
        Map<String, Col> byKey = new HashMap<>();
        for (Col c : cols) byKey.put(sourceKey(c), c);
        try (Connection dm = DriverManager.getConnection(DM_URL, DM_USER, DM_PASS)) {
            for (FieldDef f : fields.values()) {
                StringBuilder desc = new StringBuilder();
                desc.append("字段描述：").append(f.name)
                        .append("，由词根[").append(String.join(",", f.roots)).append("]组成")
                        .append("；字段状态：").append("ACTIVE".equals(f.status) ? "已确认" : "待确认")
                        .append("；置信等级：").append(f.level);
                desc.append("；来源字段：");
                List<String> refs = new ArrayList<>();
                for (Col ex : f.examples) refs.add(ex.owner + "." + ex.tableName + "." + ex.columnName);
                desc.append(String.join("|", refs));
                if (isEnumLike(f)) {
                    List<String> enumValues = collectEnumValues(dm, f.examples);
                    if (!enumValues.isEmpty()) {
                        desc.append("；枚举值：").append(String.join("/", enumValues));
                    } else {
                        desc.append("；枚举值：未采集到稳定有限值");
                    }
                }
                f.definition = trimDefinition(f.definition + "；" + desc, 500);
            }
        } catch (SQLException e) {
            for (FieldDef f : fields.values()) {
                f.definition = trimDefinition(f.definition + "；字段描述：" + f.name + "，由词根[" + String.join(",", f.roots) + "]组成；枚举值：采集失败", 500);
            }
        }
    }

    private static boolean isEnumLike(FieldDef f) {
        return f.roots.stream().anyMatch(r -> Set.of("zhuangtai", "leixing", "leibie", "dengji", "biaozhi", "biaoshi", "bizhong", "bibie").contains(r));
    }

    private static List<String> collectEnumValues(Connection dm, List<Col> examples) {
        LinkedHashSet<String> values = new LinkedHashSet<>();
        for (Col c : examples) {
            if (values.size() >= 10) break;
            String sql = "SELECT DISTINCT " + quoteDm(c.columnName) + " AS V FROM " + quoteDm(c.owner) + "." + quoteDm(c.tableName)
                    + " WHERE " + quoteDm(c.columnName) + " IS NOT NULL AND ROWNUM <= 200";
            try (PreparedStatement ps = dm.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next() && values.size() < 10) {
                    String v = maskValue(rs.getString("V"));
                    if (!v.isBlank() && v.length() <= 32) values.add(v);
                }
            } catch (SQLException ignored) {
                // Some source tables may be inaccessible or special views; skip them.
            }
        }
        return new ArrayList<>(values);
    }

    private static String quoteDm(String id) {
        return "\"" + nvl(id).replace("\"", "\"\"") + "\"";
    }

    private static String sourceKey(Col c) {
        return nvl(c.owner) + "." + nvl(c.tableName) + "." + nvl(c.columnName);
    }

    private static String maskValue(String s) {
        String v = nvl(s).trim().replaceAll("\\s+", " ");
        if (v.matches("1\\d{10}")) return v.substring(0, 3) + "****" + v.substring(7);
        if (v.matches("\\d{15}|\\d{17}[0-9Xx]")) return v.substring(0, 6) + "********" + v.substring(v.length() - 4);
        return v.replace(",", "，").replace(";", "；").replace("；", "、");
    }

    private static String trimDefinition(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 3) + "...";
    }

    private static void seedBaseRoots(Map<String, RootDef> roots) {
        for (String[] r : BASE_ROOTS) {
            roots.putIfAbsent(r[0], new RootDef(r[0], r[1], r[2]));
        }
    }

    private static void upsertRoot(Map<String, RootDef> roots, String code, String name, String domain, String status) {
        RootDef existing = roots.get(code);
        if (existing == null) {
            roots.put(code, new RootDef(code, name, domain, status));
            return;
        }
        if ("ACTIVE".equals(status) && !"ACTIVE".equals(existing.status)) {
            existing.status = "ACTIVE";
            existing.name = name;
            existing.domain = domain;
        }
    }

    private static void clearDictionaryTables(Connection c) throws SQLException {
        try (Statement st = c.createStatement()) {
            st.executeUpdate("DELETE FROM om_root_synonym WHERE tenant_id=" + TENANT_ID);
            st.executeUpdate("DELETE FROM om_root_field_map WHERE tenant_id=" + TENANT_ID);
            st.executeUpdate("DELETE FROM om_standard_field WHERE tenant_id=" + TENANT_ID);
            st.executeUpdate("DELETE FROM om_term_root WHERE tenant_id=" + TENANT_ID);
        }
    }

    private static boolean isPlatformMetadataPhrase(String chinese) {
        if (BAD_COMMENT.contains(chinese)) return true;
        String[] patterns = {
                "表标识", "表标题", "表定义", "目标表", "源表", "关联模板", "定义数据", "适应条件", "生单时机",
                "配置节点", "审批节点", "表单分类", "配置", "设置", "模板", "按钮控制",
                "标准字段", "字段映射", "字段注释", "字段分组", "字段排序", "字段长度", "字段顺序",
                "表结构", "表名", "接口字段", "对象主键", "消息队列", "流程实例", "流程节点",
                "权限描述", "菜单图标", "同步缓存", "索引", "租户服务", "服务节点", "模型", "任务", "日志", "审计"
        };
        for (String p : patterns) {
            if (chinese.contains(p)) return true;
        }
        return false;
    }

    private static boolean hasHomophoneConflict(List<String> terms, List<String> rootCodes) {
        for (int i = 0; i < terms.size() && i < rootCodes.size(); i++) {
            if ("事件".equals(terms.get(i)) && "shijian".equals(rootCodes.get(i))) {
                return true;
            }
        }
        return false;
    }

    private static void writeSynonyms(Connection c, Map<String, Long> rootIds) throws SQLException {
        String[][] syns = {{"bianhao","bianma","NEAR"},{"zuzhi","bumen","NEAR"},{"shouji","dianhua","NEAR"},{"shenfenzheng","zhengjian","NEAR"}};
        try (PreparedStatement ps = c.prepareStatement("INSERT IGNORE INTO om_root_synonym (tenant_id, root_id, synonym_root_id, relation_type, weight_score, status) VALUES (?,?,?,?,1.00,'ACTIVE')")) {
            for (String[] s : syns) {
                Long a = rootIds.get(s[0]), b = rootIds.get(s[1]);
                if (a == null || b == null || Objects.equals(a,b)) continue;
                ps.setLong(1, TENANT_ID); ps.setLong(2, a); ps.setLong(3, b); ps.setString(4, s[2]); ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    private static Map<String, Long> loadIds(Connection c, String table, String col) throws SQLException {
        Map<String, Long> out = new HashMap<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT id," + col + " FROM " + table + " WHERE tenant_id=?")) {
            ps.setLong(1, TENANT_ID);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.put(rs.getString(2), rs.getLong(1)); }
        }
        return out;
    }

    private static String extractChinese(String s) { return s == null ? "" : s.replaceAll("[^\\u4e00-\\u9fa5]", ""); }
    private static String clean(String s) { return s == null ? "" : s.trim().replaceAll("\\s+", ""); }
    private static String nvl(String s) { return s == null ? "" : s; }
    private static String normalizeType(String dmType) {
        String t = nvl(dmType).toUpperCase(Locale.ROOT);
        if (t.contains("INT") || t.contains("NUMBER") || t.contains("DECIMAL") || t.contains("NUMERIC")) return "number";
        if (t.contains("DATE") || t.contains("TIME")) return "datetime";
        if (t.contains("CLOB") || t.contains("TEXT")) return "longtext";
        return "string";
    }
    private static String guessDomain(String owner, String tableComment, String chinese) {
        String x = (nvl(owner) + " " + nvl(tableComment) + " " + nvl(chinese)).toLowerCase(Locale.ROOT);
        if (x.contains("fin") || x.contains("财务") || x.contains("会计") || x.contains("凭证") || x.contains("科目")) return "finance";
        if (x.contains("inv") || x.contains("投资") || x.contains("项目") || x.contains("资金")) return "investment";
        if (x.contains("hr") || x.contains("人事") || x.contains("员工") || x.contains("薪酬") || x.contains("岗位")) return "hr";
        return "common";
    }
    private static String toPinyin(String s) {
        HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();
        format.setCaseType(HanyuPinyinCaseType.LOWERCASE);
        format.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            try {
                String[] arr = PinyinHelper.toHanyuPinyinStringArray(ch, format);
                if (arr != null && arr.length > 0) sb.append(arr[0].replace("u:", "v"));
            } catch (Exception ignored) { }
        }
        return sb.toString();
    }
}
