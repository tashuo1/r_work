import os
#!/usr/bin/env python3
import pymysql


def connect():
    return pymysql.connect(
        host=os.getenv("CIZHU_MYSQL_HOST", "127.0.0.1"),
        port=int(os.getenv("CIZHU_MYSQL_PORT", "3306")),
        user=os.getenv("CIZHU_MYSQL_USER", "root"),
        password=os.getenv("CIZHU_MYSQL_PASSWORD", ""),
        database=os.getenv("CIZHU_MYSQL_DATABASE", "ontology_meta"),
        charset="utf8mb4",
        autocommit=False,
    )


def main():
    conn = connect()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE om_term_root
                SET source_type = COALESCE(source_type,
                    CASE
                      WHEN biz_definition LIKE '%jieba%' THEN 'JIEBA'
                      WHEN biz_definition LIKE '%UNSPLIT%' THEN 'RULE'
                      ELSE 'RULE'
                    END),
                    confidence_level = COALESCE(confidence_level,
                    CASE
                      WHEN status='ACTIVE' THEN 'AUTO'
                      ELSE 'PENDING_REVIEW'
                    END),
                    review_note = COALESCE(review_note,
                    CASE
                      WHEN status='ACTIVE' THEN '已确认词根'
                      WHEN status='DRAFT' THEN '候选词根，待人工审核'
                      ELSE '保留负样本'
                    END)
                WHERE tenant_id=1
                """
            )
            roots = cur.rowcount
            cur.execute(
                """
                UPDATE om_standard_field
                SET source_type = COALESCE(source_type,
                    CASE
                      WHEN biz_definition LIKE '%JIEBA%' OR biz_definition LIKE '%jieba%' THEN 'JIEBA'
                      WHEN biz_definition LIKE '%UNSPLIT%' THEN 'RULE'
                      ELSE 'RULE'
                    END),
                    confidence_level = COALESCE(confidence_level,
                    CASE
                      WHEN status='ACTIVE' THEN 'AUTO'
                      ELSE 'PENDING_REVIEW'
                    END),
                    review_note = COALESCE(review_note,
                    CASE
                      WHEN status='ACTIVE' THEN '已确认标准字段'
                      WHEN status='DRAFT' THEN '候选标准字段，待人工审核'
                      ELSE '保留负样本'
                    END)
                WHERE tenant_id=1
                """
            )
            fields = cur.rowcount
        conn.commit()
        print(f"ROOTS_BACKFILLED={roots}")
        print(f"FIELDS_BACKFILLED={fields}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
