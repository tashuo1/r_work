#!/usr/bin/env python3
import argparse
import csv
import os
import re
import subprocess
from pathlib import Path

import pymysql
from pymysql.err import IntegrityError


DEFAULT_INPUT = Path("tools/review_out/jieba_tokenizer_candidates.csv")
WHITELIST_INPUT = Path("tools/review_out/jieba_root_whitelist_candidates.csv")
TENANT_ID = 1
COMPOUND_TOKEN_SPLITS = {
    "期末余额": ["期末", "余额"],
    "期初余额": ["期初", "余额"],
    "年末余额": ["年末", "余额"],
    "年初余额": ["年初", "余额"],
    "本年金额": ["本年", "金额"],
    "上年金额": ["上年", "金额"],
}
NOISE_TOKENS = {"是否", "是否是", "是", "否", "待处理", "成功失败", "处理完成", "不处理"}


def pinyin(text):
    script = "import sys; from pypinyin import lazy_pinyin; print(''.join(lazy_pinyin(sys.argv[1])))"
    try:
        return subprocess.check_output(["python", "-c", script, text], text=True, encoding="utf-8").strip()
    except Exception:
        return ""


def connect():
    return pymysql.connect(
        host=os.getenv("CIZHU_MYSQL_HOST", "127.0.0.1"),
        port=int(os.getenv("CIZHU_MYSQL_PORT", "3306")),
        user=os.getenv("CIZHU_MYSQL_USER", "root"),
        password=os.getenv("CIZHU_MYSQL_PASSWORD", ""),
        database=os.getenv("CIZHU_MYSQL_DATABASE", "ontology_meta"),
        charset="utf8mb4",
        autocommit=False,
    )


def load_allowed_unknowns():
    allowed = set()
    if not WHITELIST_INPUT.exists():
        return allowed
    with WHITELIST_INPUT.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("decision") == "RECOMMEND_DRAFT_ROOT":
                allowed.add(row.get("token", ""))
    return allowed


def load_roots(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT id, root_code, root_name, domain_name, status FROM om_term_root WHERE tenant_id=%s", (TENANT_ID,))
        by_name = {}
        by_code = {}
        for rid, code, name, domain, status in cur.fetchall():
            by_name[name] = {"id": rid, "code": code, "name": name, "domain": domain, "status": status}
            by_code[code] = by_name[name]
        return by_name, by_code


def expand_tokens(tokens):
    out = []
    for token in tokens:
        if not token or token in NOISE_TOKENS:
            continue
        out.extend(COMPOUND_TOKEN_SPLITS.get(token, [token]))
    return out


def insert_root(conn, token, by_name, by_code):
    code = pinyin(token)
    if not re.fullmatch(r"[a-z]+", code or ""):
        return None
    if code in by_code:
        return by_code[code] if by_code[code]["name"] == token else None
    status = "ACTIVE" if len(token) <= 2 else "DRAFT"
    confidence = "AUTO" if status == "ACTIVE" else "PENDING_REVIEW"
    note = "短原子词根，分词器候选自动通过" if status == "ACTIVE" else "候选词根，待人工审核"
    definition_prefix = "规范词根" if status == "ACTIVE" else "待确认词根"
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO om_term_root
                    (tenant_id, root_code, root_name, biz_definition, domain_name, status,
                     source_type, confidence_level, review_note)
                VALUES (%s,%s,%s,%s,%s,%s,'JIEBA',%s,%s)
                """,
                (TENANT_ID, code, token, f"{definition_prefix}：{token}；来源：jieba 分词候选；状态：{note}", "business", status, confidence, note),
            )
            rid = cur.lastrowid
    except IntegrityError:
        conn.rollback()
        return None
    row = {"id": rid, "code": code, "name": token, "domain": "business", "status": status}
    by_name[token] = row
    by_code[code] = row
    return row


def insert_field(conn, field_code, field_name, count, sample):
    with conn.cursor() as cur:
        cur.execute("SELECT id FROM om_standard_field WHERE tenant_id=%s AND field_code=%s", (TENANT_ID, field_code))
        row = cur.fetchone()
        if row:
            return row[0], False
        definition = f"口径：{field_name}；来源：jieba 分词候选；生成方式：JIEBA_CANDIDATE_DRAFT；置信状态：待确认；覆盖物理字段数：{count}；样例：{sample[:120]}"
        cur.execute(
            "INSERT INTO om_standard_field (tenant_id, field_code, field_name, field_type, biz_definition, combo_key, status) VALUES (%s,%s,%s,'STRING',%s,%s,'DRAFT')",
            (TENANT_ID, field_code, field_name, definition[:500], "jieba_" + field_code),
        )
        return cur.lastrowid, True


def insert_map(conn, root_id, field_id):
    with conn.cursor() as cur:
        cur.execute(
            "INSERT IGNORE INTO om_root_field_map (tenant_id, root_id, standard_field_id, relation_type, weight_score, status) VALUES (%s,%s,%s,'SYNONYM',1.00,'INACTIVE')",
            (TENANT_ID, root_id, field_id),
        )
        return cur.rowcount


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=str(DEFAULT_INPUT))
    parser.add_argument("--limit", type=int, default=800)
    parser.add_argument("--allow-unknown", action="store_true")
    args = parser.parse_args()

    conn = connect()
    roots_inserted = fields_inserted = maps_inserted = skipped = processed = 0
    try:
        by_name, by_code = load_roots(conn)
        allowed_unknowns = load_allowed_unknowns()
        with open(args.input, "r", encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                if processed >= args.limit:
                    break
                if row.get("decision") != "CANDIDATE_DRAFT":
                    skipped += 1
                    continue
                tokens = expand_tokens(row.get("accepted_tokens", "").split("/"))
                if len(tokens) < 2 or len(tokens) > 10:
                    skipped += 1
                    continue
                root_rows = []
                ok = True
                for token in tokens:
                    root = by_name.get(token)
                    if root is None and args.allow_unknown and token in allowed_unknowns and 2 <= len(token) <= 4:
                        root = insert_root(conn, token, by_name, by_code)
                        if root:
                            roots_inserted += 1
                    if root is None:
                        ok = False
                        break
                    root_rows.append(root)
                if not ok:
                    skipped += 1
                    continue
                field_code = "_".join(r["code"] for r in root_rows)
                if len(field_code) > 128:
                    skipped += 1
                    continue
                field_name = "".join(r["name"] for r in root_rows)
                field_id, created = insert_field(conn, field_code, field_name, int(row.get("count") or 0), row.get("sample", ""))
                if created:
                    fields_inserted += 1
                for root in root_rows:
                    maps_inserted += insert_map(conn, root["id"], field_id)
                processed += 1
                if processed % 50 == 0:
                    conn.commit()
        conn.commit()
    finally:
        conn.close()
    print(f"PROCESSED={processed}")
    print(f"DRAFT_ROOTS_INSERTED={roots_inserted}")
    print(f"DRAFT_FIELDS_INSERTED={fields_inserted}")
    print(f"INACTIVE_MAPS_INSERTED={maps_inserted}")
    print(f"SKIPPED={skipped}")


if __name__ == "__main__":
    main()
