import os
#!/usr/bin/env python3
import csv
from pathlib import Path

import pymysql


UNCOVERED = Path("tools/review_out/dm_standard_uncovered.csv")
JIEBA = Path("tools/review_out/jieba_tokenizer_candidates.csv")


def connect():
    return pymysql.connect(
        host=os.getenv("CIZHU_MYSQL_HOST", "127.0.0.1"),
        port=int(os.getenv("CIZHU_MYSQL_PORT", "3306")),
        user=os.getenv("CIZHU_MYSQL_USER", "root"),
        password=os.getenv("CIZHU_MYSQL_PASSWORD", ""),
        database=os.getenv("CIZHU_MYSQL_DATABASE", "ontology_meta"),
        charset="utf8mb4",
    )


def main():
    conn = connect()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT field_code,status FROM om_standard_field WHERE tenant_id=1")
            fields = dict(cur.fetchall())
            cur.execute("SELECT root_code,root_name FROM om_term_root WHERE tenant_id=1")
            roots = {name: code for code, name in cur.fetchall()}
    finally:
        conn.close()

    uncovered_counts = {}
    with UNCOVERED.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("business", "").lower() == "true" and row.get("match_status") not in {"ACTIVE", "DRAFT"}:
                uncovered_counts[row.get("semantic_cn", "")] = uncovered_counts.get(row.get("semantic_cn", ""), 0) + 1

    extra = active = draft = 0
    with JIEBA.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            semantic = row.get("semantic_cn", "")
            if semantic not in uncovered_counts or row.get("decision") != "CANDIDATE_DRAFT":
                continue
            codes = []
            ok = True
            for token in [t for t in row.get("accepted_tokens", "").split("/") if t]:
                code = roots.get(token)
                if not code:
                    ok = False
                    break
                codes.append(code)
            if not ok or not codes:
                continue
            status = fields.get("_".join(codes))
            if status:
                n = uncovered_counts[semantic]
                extra += n
                if status == "ACTIVE":
                    active += n
                elif status == "DRAFT":
                    draft += n
    print(f"JIEBA_EXTRA_FIELD_COVERAGE={extra}")
    print(f"JIEBA_ACTIVE_EXTRA={active}")
    print(f"JIEBA_DRAFT_EXTRA={draft}")


if __name__ == "__main__":
    main()
