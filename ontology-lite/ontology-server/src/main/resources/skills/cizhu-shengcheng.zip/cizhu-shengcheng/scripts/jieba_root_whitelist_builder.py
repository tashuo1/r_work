#!/usr/bin/env python3
import csv
import re
from collections import Counter, defaultdict
from pathlib import Path


INPUT = Path("tools/review_out/jieba_tokenizer_candidates.csv")
OUT = Path("tools/review_out/jieba_root_whitelist_candidates.csv")

BAD = {
    "是否", "是否是", "已", "是", "否", "待处理", "成功失败", "处理完成", "不处理",
    "其他", "其中", "本", "上", "年", "月", "日", "第一期"
    , "以号", "填列", "年数"
}
COMPOUND_FIELD_TOKENS = {"期末余额", "期初余额", "年末余额", "年初余额", "本年金额", "上年金额"}
BAD_RE = re.compile(r"(本$|上$|第|是否|待处理|成功|失败|处理|不处理|栏次|十大|号填列|填列|以号|十可供|项本|率本|次本)")
BUSINESS_RE = re.compile(r"(金额|余额|资本|股东|资产|负债|权益|收入|费用|利润|金融|出资|公积|收益|储备|准备|应收|存货|凭证|会计|税|合同|项目|客户|组织|银行|流水|收款|付款|发票)")


def decision(token, total_count, categories):
    if not token or token in BAD:
        return "REJECT", "noise_token"
    if token in COMPOUND_FIELD_TOKENS:
        return "REJECT", "field_level_compound_token"
    if len(token) == 1:
        return "REJECT", "single_char"
    if len(token) > 4:
        return "PENDING_REVIEW", "too_long_for_auto_whitelist"
    if BAD_RE.search(token):
        return "REJECT", "unstable_boundary_or_enum_tail"
    if total_count >= 8 and (BUSINESS_RE.search(token) or "FINANCE_REPORT_METRIC" in categories):
        return "RECOMMEND_DRAFT_ROOT", "high_frequency_business_token"
    if total_count >= 15:
        return "PENDING_REVIEW", "high_frequency_but_domain_unclear"
    return "PENDING_REVIEW", "low_frequency"


def main():
    counts = Counter()
    samples = defaultdict(list)
    categories = defaultdict(set)
    with INPUT.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("decision") != "CANDIDATE_DRAFT":
                continue
            n = int(row.get("count") or 0)
            for token in [x for x in row.get("unknown_tokens", "").split("/") if x]:
                counts[token] += n
                categories[token].add(row.get("category", ""))
                if len(samples[token]) < 3:
                    samples[token].append(row.get("semantic_cn", ""))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", encoding="utf-8", newline="") as g:
        writer = csv.DictWriter(g, fieldnames=["token", "count", "decision", "reason", "categories", "samples"])
        writer.writeheader()
        for token, total in counts.most_common():
            d, reason = decision(token, total, categories[token])
            writer.writerow({
                "token": token,
                "count": total,
                "decision": d,
                "reason": reason,
                "categories": "/".join(sorted(categories[token])),
                "samples": " | ".join(samples[token]),
            })
    print(f"WHITELIST_CANDIDATES={len(counts)}")
    print(f"OUT={OUT}")


if __name__ == "__main__":
    main()
