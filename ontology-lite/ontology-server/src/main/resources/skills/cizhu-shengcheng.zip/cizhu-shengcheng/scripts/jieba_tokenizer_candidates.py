#!/usr/bin/env python3
import argparse
import csv
import os
import re
from pathlib import Path

import jieba


SKILL_REF = Path(os.getenv("CIZHU_SKILL_HOME", ".")) / "references"
DEFAULT_INPUT = Path("tools/review_out/unsplit_review_candidates.csv")
DEFAULT_OUTPUT = Path("tools/review_out/jieba_tokenizer_candidates.csv")

PLATFORM_RE = re.compile(r"(交换器|客户端|事务|数据流|主表|版本号|校验码|删除关联|短文本|整数|操作人|创建人|最后操作人)")
BAD_TOKEN_RE = re.compile(r"^[的一是在与及或第]+$")
FIELD_SUFFIXES = ("时间", "日期", "名称", "编号", "编码", "类型", "状态", "金额", "号码", "代码", "标志", "标识", "标题", "说明", "地址", "次数", "原因", "参数", "结果", "内容", "总数", "方案", "单位", "余额")


def parse_roots():
    roots = {}
    for name in ["common-roots.yml", "domain-roots-finance.yml", "domain-roots-hr.yml", "domain-roots-investment.yml"]:
        path = SKILL_REF / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        for m in re.finditer(r"code:\s*([^,}\s]+).*?name:\s*([^,}\s]+)", text):
            code, root_name = m.group(1).strip(), m.group(2).strip()
            if re.fullmatch(r"[a-z]+", code):
                roots[root_name] = code
    return roots


def load_jieba_dict(roots):
    for word in sorted(roots, key=len, reverse=True):
        if word:
            jieba.add_word(word, freq=200000, tag="nz")


def is_good_token(token):
    token = token.strip()
    if not token or BAD_TOKEN_RE.fullmatch(token):
        return False
    if re.fullmatch(r"[0-9A-Za-z_]+", token):
        return False
    if len(token) == 1 and token not in {"年", "月", "日"}:
        return False
    if len(token) > 4 and token.endswith(FIELD_SUFFIXES):
        return False
    if PLATFORM_RE.search(token):
        return False
    return True


def candidate_for(semantic, roots):
    raw_tokens = [t.strip() for t in jieba.lcut(semantic, HMM=True) if t.strip()]
    tokens = []
    reject = []
    for token in raw_tokens:
        if is_good_token(token):
            tokens.append(token)
        else:
            reject.append(token)
    root_codes = []
    unknown = []
    for token in tokens:
        code = roots.get(token)
        if code:
            root_codes.append(code)
        else:
            unknown.append(token)
    if len(tokens) < 2:
        return raw_tokens, tokens, root_codes, unknown, "TOKEN_TOO_SHORT"
    if any(len(t) > 6 for t in unknown):
        return raw_tokens, tokens, root_codes, unknown, "UNKNOWN_TOKEN_TOO_LONG"
    if not root_codes and len(unknown) > 4:
        return raw_tokens, tokens, root_codes, unknown, "TOO_MANY_UNKNOWN_TOKENS"
    return raw_tokens, tokens, root_codes, unknown, ""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=str(DEFAULT_INPUT))
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--limit", type=int, default=3000)
    args = parser.parse_args()

    roots = parse_roots()
    load_jieba_dict(roots)

    inp = Path(args.input)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)

    written = 0
    with inp.open("r", encoding="utf-8-sig", newline="") as f, out.open("w", encoding="utf-8", newline="") as g:
        reader = csv.DictReader(f)
        writer = csv.DictWriter(g, fieldnames=[
            "semantic_cn", "count", "category", "raw_tokens", "accepted_tokens",
            "known_root_codes", "unknown_tokens", "decision", "reject_reason", "sample"
        ])
        writer.writeheader()
        for row in reader:
            if written >= args.limit:
                break
            semantic = row.get("semantic_cn", "")
            category = row.get("category", "")
            if category == "TECH_PLATFORM" or PLATFORM_RE.search(semantic):
                decision = "REJECTED"
                raw_tokens, tokens, root_codes, unknown, reason = [], [], [], [], "TECH_PLATFORM"
            else:
                raw_tokens, tokens, root_codes, unknown, reason = candidate_for(semantic, roots)
                decision = "CANDIDATE_DRAFT" if not reason else "PENDING_REVIEW"
            writer.writerow({
                "semantic_cn": semantic,
                "count": row.get("count", ""),
                "category": category,
                "raw_tokens": "/".join(raw_tokens),
                "accepted_tokens": "/".join(tokens),
                "known_root_codes": "/".join(root_codes),
                "unknown_tokens": "/".join(unknown),
                "decision": decision,
                "reject_reason": reason,
                "sample": row.get("sample", ""),
            })
            written += 1
    print(f"JIEBA_CANDIDATES_WRITTEN={written}")
    print(f"OUT={out}")


if __name__ == "__main__":
    main()
