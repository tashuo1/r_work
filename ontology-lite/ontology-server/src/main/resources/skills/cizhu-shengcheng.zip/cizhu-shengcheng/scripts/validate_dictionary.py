#!/usr/bin/env python3
import argparse
import csv
import json
import re
from pathlib import Path

COMPOUND_SUFFIXES = (
    "shijian", "riqi", "mingcheng", "bianhao", "bianma", "leixing",
    "zhuangtai", "jine", "haoma", "daima", "biaozhi", "biaoshi",
    "biaoti", "shuoming", "dizhi", "dingyi", "moban", "shuju",
    "tiaojian", "yiju", "shiji", "cishu", "xingshu", "yuanyin",
    "canshu", "jieguo", "xiaoxi", "neirong", "haoshi", "zongshu",
    "miaoshu", "fangan", "danwei", "guize", "duixiang", "zhujian",
    "biaoming", "ziduan", "yingshe", "zhushi", "duilie", "liucheng",
    "jiedian", "quanxian", "huancun", "suoyin", "lujing", "shunxu",
    "xuhao", "fanwei", "fangshi", "jilushu", "zijie", "zhangdu",
    "daxiao", "shouru", "zhichu", "lirun", "zonge",
)

CHINESE_COMPOUND_SUFFIXES = (
    "时间", "日期", "名称", "编号", "编码", "类型", "状态", "金额", "号码", "代码",
    "标志", "标识", "标题", "说明", "地址", "定义", "模板", "数据", "条件", "依据", "时机",
    "值",
    "次数", "率", "行数", "原因", "参数", "结果", "消息", "内容", "耗时", "总数",
    "描述", "方案", "单位", "规则", "对象", "主键", "表名", "字段", "映射", "注释",
    "队列", "流程", "节点", "权限", "缓存", "索引", "路径", "顺序", "序号", "范围",
    "方式", "记录数", "字节", "长度", "大小", "收入", "支出", "利润", "余额", "总额",
)

KNOWN_ALLOWED_COMPOUND_ROOTS = {"shenfenzheng", "yingyezhizhao", "lilv"}

FORBIDDEN_ROOTS = {
    "yonghuleixing", "xiugaishijian", "caozuoshijian", "danjubianhao",
    "fujibiaoshi", "moxingbiaoshi", "kehumingcheng", "biaobiaoshi",
    "biaobiaoti", "mubiaobiao", "mubiaobiaodingyi", "guanlianmoban",
    "qingqiucishu", "chenggongcishu", "shibaicishu", "biangengcishu",
    "chufacishu", "chuxiancishu", "cuowucishu", "dayincishu",
    "shiyongcishu", "zhixingcishu", "zhongshicishu", "chenggonglv",
    "shibaixingshu", "shibaiyuanyin", "qingqiucanshu",
    "banbenmiaoshu", "baobiaofangan", "biaozhunziduan", "caozuomiaoshu",
    "chanpinshuliang", "duixiangzhujian", "fujibiaoming", "jiekouziduan",
    "quanxianmiaoshu", "xiaoxiduilie", "ziduanyingshe", "ziduanzhushi",
    "zongjilushu",
}

PLATFORM_METADATA_NAMES = {
    "表标识", "表标题", "表定义", "目标表", "源表", "目标表定义", "源表定义",
    "关联模板", "定义数据", "适应条件", "生单时机", "配置节点", "审批节点", "表单分类",
    "标准字段", "字段映射", "字段注释", "字段分组", "字段排序", "字段长度", "字段顺序",
    "表结构", "表名", "接口字段", "对象主键", "消息队列", "流程实例", "流程节点",
    "权限描述", "菜单图标", "同步缓存", "索引", "租户服务", "服务节点",
}


def load_rows(path):
    if not path:
        return []
    p = Path(path)
    if not p.exists():
        raise SystemExit(f"missing file: {p}")
    text = p.read_text(encoding="utf-8-sig")
    if p.suffix.lower() == ".json":
        data = json.loads(text)
        if isinstance(data, dict):
            for key in ("rows", "data", "items"):
                if isinstance(data.get(key), list):
                    return data[key]
            return [data]
        return data
    with p.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def get(row, *names):
    lowered = {str(k).lower(): v for k, v in row.items()}
    for name in names:
        if name in row:
            return row.get(name)
        if name.lower() in lowered:
            return lowered[name.lower()]
    return ""


def norm(value):
    return str(value or "").strip()


def is_auxiliary(row):
    definition = norm(get(row, "biz_definition", "definition"))
    root_type = norm(get(row, "root_type", "type"))
    return (
        root_type.upper() in {"AUX", "AUXILIARY"}
        or "辅助识别词根" in definition
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--roots")
    parser.add_argument("--fields")
    parser.add_argument("--maps")
    parser.add_argument("--synonyms")
    args = parser.parse_args()

    roots = load_rows(args.roots)
    fields = load_rows(args.fields)
    maps = load_rows(args.maps)
    synonyms = load_rows(args.synonyms)

    findings = []
    root_codes = set()
    auxiliary_roots = set()

    for i, row in enumerate(roots, 1):
        code = norm(get(row, "root_code", "code"))
        name = norm(get(row, "root_name", "name"))
        if not code:
            findings.append(("ROOT_MISSING_CODE", i, "root_code is empty"))
            continue
        if code in root_codes:
            findings.append(("DUPLICATE_ROOT", i, code))
        root_codes.add(code)
        if is_auxiliary(row):
            auxiliary_roots.add(code)
        if "_" in code:
            findings.append(("ROOT_HAS_UNDERSCORE", i, code))
        if not re.fullmatch(r"[a-z]+", code):
            findings.append(("ROOT_NOT_LOWER_PINYIN", i, code))
        if code in FORBIDDEN_ROOTS:
            findings.append(("FORBIDDEN_COMPOUND_ROOT", i, code))
        if name in PLATFORM_METADATA_NAMES:
            findings.append(("PLATFORM_METADATA_ROOT", i, f"{code}:{name}"))
        if code not in KNOWN_ALLOWED_COMPOUND_ROOTS:
            for suffix in COMPOUND_SUFFIXES:
                if code.endswith(suffix) and len(code) > len(suffix) + 2:
                    findings.append(("SUSPECT_COMPOUND_ROOT", i, code))
                    break
            for suffix in CHINESE_COMPOUND_SUFFIXES:
                if name.endswith(suffix) and len(name) > len(suffix):
                    findings.append(("SUSPECT_COMPOUND_ROOT_NAME", i, f"{code}:{name}"))
                    break

    field_codes = set()
    field_segments = {}
    for i, row in enumerate(fields, 1):
        code = norm(get(row, "field_code", "code"))
        if not code:
            findings.append(("FIELD_MISSING_CODE", i, "field_code is empty"))
            continue
        if code in field_codes:
            findings.append(("DUPLICATE_FIELD", i, code))
        field_codes.add(code)
        if not re.fullmatch(r"[a-z]+(_[a-z]+)*", code):
            findings.append(("FIELD_BAD_FORMAT", i, code))
        segments = code.split("_")
        field_segments[code] = set(segments)
        for seg in segments:
            if seg not in root_codes:
                findings.append(("UNKNOWN_FIELD_SEGMENT", i, f"{code}: {seg}"))
            if seg in auxiliary_roots:
                findings.append(("AUXILIARY_ROOT_USED_IN_FIELD", i, f"{code}: {seg}"))

    mapped = {code: set() for code in field_codes}
    field_status = {}
    for row in fields:
        field_status[norm(get(row, "field_code", "code"))] = norm(get(row, "status")).upper()
    for i, row in enumerate(maps, 1):
        root = norm(get(row, "root_code", "root"))
        field = norm(get(row, "field_code", "standard_field_code", "field"))
        relation = norm(get(row, "relation_type", "relation")).upper() or "SYNONYM"
        map_status = norm(get(row, "status")).upper()
        if field and field not in field_codes:
            findings.append(("MAP_UNKNOWN_FIELD", i, field))
        if root and root not in root_codes:
            findings.append(("MAP_UNKNOWN_ROOT", i, root))
        if relation == "SYNONYM" and field in mapped and root in root_codes:
            mapped[field].add(root)
        if relation == "SYNONYM" and root in auxiliary_roots:
            findings.append(("AUXILIARY_ROOT_USED_IN_FIELD_MAP", i, root))
        if field_status.get(field) == "DRAFT" and map_status == "ACTIVE":
            findings.append(("DRAFT_FIELD_HAS_ACTIVE_MAP", i, field))

    for code, segments in field_segments.items():
        missing = segments - mapped.get(code, set())
        if maps and missing:
            findings.append(("INCOMPLETE_FIELD_MAP", code, ",".join(sorted(missing))))

    for i, row in enumerate(synonyms, 1):
        root = norm(get(row, "root_code", "root"))
        synonym = norm(get(row, "synonym_root_code", "synonym"))
        if "_" in root or "_" in synonym:
            findings.append(("SYNONYM_POINTS_TO_FIELD", i, f"{root}->{synonym}"))
        if root == synonym and root:
            findings.append(("SELF_SYNONYM", i, root))
        if root and root not in root_codes:
            findings.append(("SYNONYM_UNKNOWN_ROOT", i, root))
        if synonym and synonym not in root_codes:
            findings.append(("SYNONYM_UNKNOWN_ROOT", i, synonym))

    for finding in findings:
        print("|".join(str(x) for x in finding))
    print(f"SUMMARY roots={len(root_codes)} fields={len(field_codes)} findings={len(findings)}")
    raise SystemExit(1 if findings else 0)


if __name__ == "__main__":
    main()
